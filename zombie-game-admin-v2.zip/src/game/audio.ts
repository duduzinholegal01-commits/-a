export class AudioEngine {
  ctx: AudioContext;
  master: GainNode;
  private noiseBuf: AudioBuffer;
  private ambient: AudioNode[] = [];
  private started = false;

  constructor() {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.7;
    const comp = this.ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 6;
    this.master.connect(comp);
    comp.connect(this.ctx.destination);
    const len = this.ctx.sampleRate * 3;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }

  resume() {
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setVolume(v: number) {
    this.master.gain.value = v;
  }

  suspend() {
    void this.ctx.suspend();
  }

  private out(pan: number): AudioNode {
    if (pan === 0 || !this.ctx.createStereoPanner) return this.master;
    const p = this.ctx.createStereoPanner();
    p.pan.value = Math.max(-1, Math.min(1, pan));
    p.connect(this.master);
    return p;
  }

  private noise(dur: number, type: BiquadFilterType, f0: number, f1: number, vol: number, delay = 0, pan = 0, q = 1) {
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.Q.value = q;
    f.frequency.setValueAtTime(f0, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.out(pan));
    src.start(t, Math.random() * 2);
    src.stop(t + dur + 0.05);
  }

  private tone(type: OscillatorType, f0: number, f1: number, dur: number, vol: number, delay = 0, pan = 0) {
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(10, f1), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(this.out(pan));
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  shot(kind: string) {
    if (kind === "shotgun") {
      this.noise(0.45, "lowpass", 3200, 120, 1.0);
      this.noise(0.15, "highpass", 2500, 1500, 0.4);
      this.tone("sine", 110, 28, 0.32, 0.9);
      this.noise(0.4, "lowpass", 700, 80, 0.4, 0.09);
    } else if (kind === "rifle") {
      this.noise(0.2, "lowpass", 4200, 260, 0.85);
      this.tone("sine", 170, 45, 0.15, 0.7);
      this.noise(0.08, "highpass", 3000, 2000, 0.3);
    } else {
      this.noise(0.22, "lowpass", 4800, 300, 0.8);
      this.tone("sine", 190, 55, 0.13, 0.6);
      this.noise(0.05, "highpass", 3500, 2500, 0.3);
    }
  }

  click() {
    this.noise(0.03, "highpass", 3000, 3000, 0.35);
    this.tone("square", 900, 600, 0.03, 0.05);
  }

  reload(dur: number) {
    this.noise(0.05, "bandpass", 2000, 1500, 0.5, 0.1, 0, 3);
    this.tone("square", 500, 300, 0.05, 0.06, 0.1);
    this.noise(0.06, "bandpass", 1200, 800, 0.5, dur * 0.55, 0, 2);
    this.tone("square", 300, 200, 0.06, 0.07, dur * 0.55);
    this.noise(0.05, "highpass", 2500, 2500, 0.5, dur * 0.9);
    this.tone("square", 700, 400, 0.04, 0.06, dur * 0.9);
  }

  pump() {
    this.noise(0.07, "bandpass", 1500, 800, 0.5, 0, 0, 2);
    this.noise(0.07, "bandpass", 1000, 600, 0.5, 0.2, 0, 2);
  }

  swing() {
    this.noise(0.2, "bandpass", 500, 1800, 0.25, 0, 0, 1.2);
  }

  melee() {
    this.noise(0.12, "lowpass", 1400, 200, 0.8);
    this.tone("sine", 160, 60, 0.12, 0.6);
  }

  hurt() {
    this.tone("sine", 90, 40, 0.25, 0.8);
    this.noise(0.18, "lowpass", 600, 150, 0.6);
  }

  zombieHit(pan = 0) {
    this.noise(0.12, "lowpass", 1200, 200, 0.55, 0, pan);
    this.tone("sine", 130, 60, 0.08, 0.3, 0, pan);
  }

  headshot(pan = 0) {
    this.noise(0.1, "bandpass", 2500, 900, 0.5, 0, pan, 2);
    this.tone("triangle", 400, 120, 0.1, 0.25, 0, pan);
  }

  groan(dist: number, pan: number, pitch = 1, big = false) {
    const vol = Math.max(0, 1 - dist / 48) * (big ? 0.55 : 0.38);
    if (vol < 0.02) return;
    const t = this.ctx.currentTime;
    const dur = (big ? 1.7 : 1.1) + Math.random() * 0.6;
    const base = (big ? 52 : 78 + Math.random() * 28) * pitch;
    const o = this.ctx.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(base * 1.25, t);
    o.frequency.linearRampToValueAtTime(base * 0.8, t + dur);
    const lfo = this.ctx.createOscillator();
    lfo.frequency.value = 5 + Math.random() * 3;
    const lg = this.ctx.createGain();
    lg.gain.value = base * 0.08;
    lfo.connect(lg);
    lg.connect(o.frequency);
    const f = this.ctx.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 2.5;
    f.frequency.setValueAtTime(420 * pitch, t);
    f.frequency.linearRampToValueAtTime(680 * pitch, t + dur * 0.4);
    f.frequency.linearRampToValueAtTime(300 * pitch, t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + dur * 0.25);
    g.gain.linearRampToValueAtTime(0.0001, t + dur);
    o.connect(f);
    f.connect(g);
    g.connect(this.out(pan));
    o.start(t);
    lfo.start(t);
    o.stop(t + dur + 0.05);
    lfo.stop(t + dur + 0.05);
  }

  zombieDie(dist: number, pan: number) {
    const v = Math.max(0.2, 1 - dist / 50);
    this.tone("sawtooth", 140, 40, 0.5, 0.18 * v, 0, pan);
    this.noise(0.25, "lowpass", 900, 100, 0.4 * v, 0.05, pan);
  }

  explosion(dist: number) {
    const v = Math.max(0.35, 1 - dist / 70);
    this.noise(1.6, "lowpass", 2400, 50, 1.2 * v);
    this.tone("sine", 80, 20, 1.0, 1.0 * v);
    this.noise(0.5, "bandpass", 300, 60, 0.7 * v, 0.15, 0, 0.7);
  }

  pickup() {
    this.tone("sine", 520, 520, 0.09, 0.25);
    this.tone("sine", 780, 780, 0.12, 0.25, 0.08);
  }

  weaponPickup() {
    this.tone("triangle", 330, 330, 0.12, 0.3);
    this.tone("triangle", 495, 495, 0.12, 0.3, 0.1);
    this.tone("triangle", 660, 660, 0.25, 0.3, 0.2);
  }

  step(sprint: boolean) {
    this.noise(0.09, "bandpass", sprint ? 500 : 380, 140, sprint ? 0.28 : 0.18, 0, (Math.random() - 0.5) * 0.2, 0.8);
  }

  flashlight() {
    this.noise(0.025, "highpass", 2500, 2500, 0.3);
    this.tone("square", 1200, 900, 0.02, 0.04);
  }

  thunder(delay: number) {
    this.noise(3.2, "lowpass", 380, 40, 0.9, delay);
    this.noise(1.6, "lowpass", 700, 60, 0.6, delay + 0.4);
    this.tone("sine", 50, 25, 2.5, 0.5, delay);
  }

  heartbeat() {
    this.tone("sine", 62, 38, 0.13, 0.9);
    this.tone("sine", 58, 36, 0.14, 0.7, 0.2);
  }

  waveStart() {
    this.tone("sawtooth", 110, 108, 1.6, 0.18);
    this.tone("sawtooth", 82, 80, 1.8, 0.18);
    this.tone("sawtooth", 55, 54, 2.0, 0.2);
    this.noise(1.5, "lowpass", 300, 120, 0.2);
  }

  waveClear() {
    this.tone("triangle", 392, 392, 0.25, 0.25);
    this.tone("triangle", 494, 494, 0.25, 0.25, 0.18);
    this.tone("triangle", 587, 587, 0.5, 0.25, 0.36);
  }

  death() {
    this.tone("sine", 120, 25, 1.8, 0.9);
    this.noise(1.5, "lowpass", 800, 40, 0.5);
  }

  startAmbient() {
    if (this.started) return;
    this.started = true;
    const t = this.ctx;
    // wind
    const wind = t.createBufferSource();
    wind.buffer = this.noiseBuf;
    wind.loop = true;
    const wf = t.createBiquadFilter();
    wf.type = "bandpass";
    wf.frequency.value = 380;
    wf.Q.value = 0.8;
    const wl = t.createOscillator();
    wl.frequency.value = 0.09;
    const wlg = t.createGain();
    wlg.gain.value = 220;
    wl.connect(wlg);
    wlg.connect(wf.frequency);
    const wg = t.createGain();
    wg.gain.value = 0.16;
    wind.connect(wf);
    wf.connect(wg);
    wg.connect(this.master);
    wind.start();
    wl.start();
    // rain
    const rain = t.createBufferSource();
    rain.buffer = this.noiseBuf;
    rain.loop = true;
    rain.loopStart = 0.7;
    const rf = t.createBiquadFilter();
    rf.type = "highpass";
    rf.frequency.value = 2400;
    const rg = t.createGain();
    rg.gain.value = 0.05;
    rain.connect(rf);
    rf.connect(rg);
    rg.connect(this.master);
    rain.start();
    // drone
    const d1 = t.createOscillator();
    const d2 = t.createOscillator();
    d1.frequency.value = 43;
    d2.frequency.value = 43.7;
    d1.type = "sine";
    d2.type = "triangle";
    const dg = t.createGain();
    dg.gain.value = 0.07;
    d1.connect(dg);
    d2.connect(dg);
    dg.connect(this.master);
    d1.start();
    d2.start();
    this.ambient.push(wind, wl, rain, d1, d2);
  }

  stopAmbient() {
    for (const n of this.ambient) {
      try {
        (n as AudioScheduledSourceNode).stop();
      } catch {
        /* ignore */
      }
    }
    this.ambient = [];
    this.started = false;
  }

  dispose() {
    this.stopAmbient();
    void this.ctx.close();
  }
}
