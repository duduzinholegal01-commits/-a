import * as THREE from "three";
import type { Textures } from "./textures";
import { rng } from "./textures";
import {
  boxUV,
  planeUV,
  createCar,
  createBus,
  createBarrel,
  createCrate,
  createDumpster,
  createBarrier,
  createTree,
  createLamp,
} from "./models";

export const HALF = 60;

export interface Collider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  h: number;
  barrel?: BarrelObj;
  building?: boolean;
}

export interface BarrelObj {
  obj: THREE.Object3D;
  col: Collider;
  hp: number;
  x: number;
  z: number;
  dead: boolean;
}

export interface FireSrc {
  pos: THREE.Vector3;
  light: THREE.PointLight | null;
  t: number;
  seed: number;
}

export interface World {
  colliders: Collider[];
  barrels: BarrelObj[];
  fires: FireSrc[];
  lampLights: { light: THREE.PointLight; base: number; flicker: boolean }[];
  shotgunPos: THREE.Vector3;
  riflePos: THREE.Vector3;
}

export function buildWorld(scene: THREE.Scene, T: Textures): World {
  const rnd = rng(20240607);
  const colliders: Collider[] = [];
  const barrels: BarrelObj[] = [];
  const fires: FireSrc[] = [];
  const lampLights: World["lampLights"] = [];
  const shotgunPos = new THREE.Vector3(20, 0, 20);
  const riflePos = new THREE.Vector3(-46, 0, -46);
  const reserved: [number, number, number][] = [
    [shotgunPos.x, shotgunPos.z, 3.5],
    [riflePos.x, riflePos.z, 3.5],
    [0, 0, 5],
  ];

  const root = new THREE.Group();
  scene.add(root);

  /* ---- ground ---- */
  T.ground.repeat.set(1, 1);
  const gMat = new THREE.MeshStandardMaterial({ map: T.ground, roughness: 1, bumpMap: T.ground, bumpScale: 0.6 });
  const ground = new THREE.Mesh(planeUV(700, 700, 8), gMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  root.add(ground);

  /* ---- roads ---- */
  const roadMat = new THREE.MeshStandardMaterial({
    map: T.asphalt,
    roughness: 0.85,
    bumpMap: T.asphalt,
    bumpScale: 0.5,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  const lineMat = new THREE.MeshStandardMaterial({
    map: T.roadLine,
    transparent: true,
    roughness: 0.9,
    polygonOffset: true,
    polygonOffsetFactor: -4,
    polygonOffsetUnits: -4,
    depthWrite: false,
  });
  const road = (w: number, d: number, x: number, z: number) => {
    const m = new THREE.Mesh(planeUV(w, d, 6), roadMat);
    m.rotation.x = -Math.PI / 2;
    m.position.set(x, 0.04, z);
    m.receiveShadow = true;
    root.add(m);
  };
  road(2 * HALF, 12, 0, 0);
  road(12, HALF - 6, 0, (HALF + 6) / 2);
  road(12, HALF - 6, 0, -(HALF + 6) / 2);
  const line = (len: number, x: number, z: number, vertical: boolean) => {
    const m = new THREE.Mesh(planeUV(len, 0.35, 6, 0.35), lineMat);
    m.rotation.x = -Math.PI / 2;
    if (vertical) m.rotation.z = Math.PI / 2;
    m.position.set(x, 0.05, z);
    m.receiveShadow = true;
    root.add(m);
  };
  const L = HALF - 6;
  line(L, (HALF + 6) / 2, 0, false);
  line(L, -(HALF + 6) / 2, 0, false);
  line(L, 0, (HALF + 6) / 2, true);
  line(L, 0, -(HALF + 6) / 2, true);

  /* ---- sidewalks ---- */
  const swMat = new THREE.MeshStandardMaterial({ map: T.concrete, color: "#9a9a94", roughness: 0.95 });
  for (const qx of [-1, 1]) {
    for (const qz of [-1, 1]) {
      const a = new THREE.Mesh(boxUV(HALF - 6, 0.14, 2, 3), swMat);
      a.position.set(qx * (6 + (HALF - 6) / 2), 0.07, qz * 7);
      a.receiveShadow = true;
      root.add(a);
      const b = new THREE.Mesh(boxUV(2, 0.14, HALF - 8, 3), swMat);
      b.position.set(qx * 7, 0.07, qz * (8 + (HALF - 8) / 2));
      b.receiveShadow = true;
      root.add(b);
    }
  }

  /* ---- boundary walls ---- */
  const wallMat = new THREE.MeshStandardMaterial({ map: T.concrete, color: "#85857f", roughness: 0.95 });
  const mkWall = (w: number, d: number, x: number, z: number) => {
    const m = new THREE.Mesh(boxUV(w, 5, d, 3), wallMat);
    m.position.set(x, 2.5, z);
    m.castShadow = true;
    m.receiveShadow = true;
    root.add(m);
    colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, h: 5 });
  };
  mkWall(2 * HALF + 4, 1.5, 0, HALF + 0.75);
  mkWall(2 * HALF + 4, 1.5, 0, -HALF - 0.75);
  mkWall(1.5, 2 * HALF + 4, HALF + 0.75, 0);
  mkWall(1.5, 2 * HALF + 4, -HALF - 0.75, 0);

  /* ---- distant skyline (silhouettes in the fog) ---- */
  const facMats = T.facades.map(
    (f) =>
      new THREE.MeshStandardMaterial({
        map: f.map,
        emissiveMap: f.emissive,
        emissive: new THREE.Color("#ffffff"),
        emissiveIntensity: 0.85,
        bumpMap: f.map,
        bumpScale: 1.2,
        roughness: 0.95,
      })
  );
  const roofMat = new THREE.MeshStandardMaterial({ map: T.concrete, color: "#777", roughness: 1 });
  for (let i = 0; i < 26; i++) {
    const a = (i / 26) * Math.PI * 2 + rnd() * 0.2;
    const dist = 95 + rnd() * 40;
    const w = 14 + rnd() * 18;
    const h = 24 + ((rnd() * 10) | 0) * 4;
    const m = new THREE.Mesh(
      boxUV(w, h, w, 8),
      [0, 1, 2, 3, 4, 5].map((k) => (k === 2 || k === 3 ? roofMat : facMats[(rnd() * facMats.length) | 0]))
    );
    m.position.set(Math.cos(a) * dist, h / 2, Math.sin(a) * dist);
    root.add(m);
  }

  /* ---- helpers ---- */
  const overlaps = (minX: number, maxX: number, minZ: number, maxZ: number, pad: number) => {
    for (const c of colliders) {
      if (c.h < 0.5) continue;
      if (minX - pad < c.maxX && maxX + pad > c.minX && minZ - pad < c.maxZ && maxZ + pad > c.minZ) return true;
    }
    for (const [rx, rz, rr] of reserved) {
      if (minX - rr < rx && maxX + rr > rx && minZ - rr < rz && maxZ + rr > rz) return true;
    }
    return false;
  };

  const addCollider = (x: number, z: number, w: number, d: number, h: number, extra: Partial<Collider> = {}) => {
    const c: Collider = { minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, h, ...extra };
    colliders.push(c);
    return c;
  };

  const placeRect = (obj: THREE.Object3D, w: number, d: number, h: number, x: number, z: number, rot: number, pad = 0.5, check = true) => {
    const odd = Math.abs(Math.sin(rot)) > 0.5;
    const ww = odd ? d : w;
    const dd = odd ? w : d;
    if (check && overlaps(x - ww / 2, x + ww / 2, z - dd / 2, z + dd / 2, pad)) return false;
    obj.position.set(x, 0, z);
    obj.rotation.y = rot;
    root.add(obj);
    addCollider(x, z, ww, dd, h);
    return true;
  };

  const addBarrel = (x: number, z: number, kind: "red" | "blue" | "grey") => {
    if (overlaps(x - 0.35, x + 0.35, z - 0.35, z + 0.35, 0.1)) return null;
    const o = createBarrel(T, kind);
    o.position.set(x, 0, z);
    root.add(o);
    if (kind === "red") {
      const col = addCollider(x, z, 0.6, 0.6, 0.95);
      const b: BarrelObj = { obj: o, col, hp: 30, x, z, dead: false };
      col.barrel = b;
      barrels.push(b);
      return b;
    }
    addCollider(x, z, 0.6, 0.6, 0.95);
    return null;
  };

  const addFire = (x: number, z: number, light: boolean) => {
    const o = createBarrel(T, "grey");
    o.position.set(x, 0, z);
    root.add(o);
    addCollider(x, z, 0.6, 0.6, 0.95);
    let l: THREE.PointLight | null = null;
    if (light) {
      l = new THREE.PointLight("#ff8a30", 30, 24, 2);
      l.position.set(x, 1.6, z);
      root.add(l);
    }
    fires.push({ pos: new THREE.Vector3(x, 1.0, z), light: l, t: 0, seed: rnd() * 10 });
  };

  /* ---- lamps ---- */
  const lampSpots: [number, number][] = [
    [16, 7],
    [-16, -7],
    [7, -16],
    [-7, 16],
    [40, -7],
    [-40, 7],
    [7, 40],
    [-7, -40],
  ];
  lampSpots.forEach(([x, z], i) => {
    const lamp = createLamp(T);
    lamp.group.position.set(x, 0, z);
    // arm points to road center
    if (Math.abs(z) === 7) lamp.group.rotation.y = z > 0 ? Math.PI / 2 : -Math.PI / 2;
    else lamp.group.rotation.y = x > 0 ? Math.PI : 0;
    if (i === 3 || i === 6) lamp.group.rotation.z = 0.04;
    root.add(lamp.group);
    addCollider(x, z, 0.4, 0.4, 6);
    if (i < 2) {
      const l = new THREE.PointLight("#ffbf70", 55, 30, 2);
      const wp = lamp.bulbPos.clone();
      lamp.group.updateMatrixWorld(true);
      lamp.group.localToWorld(wp);
      l.position.copy(wp);
      root.add(l);
      lampLights.push({ light: l, base: 55, flicker: i === 1 });
    }
  });

  /* ---- buildings & yards ---- */
  const forcedYards = new Set(["1,1,0,0", "-1,-1,1,1", "-1,1,0,0", "1,-1,1,0"]);
  const doorMat = new THREE.MeshStandardMaterial({ map: T.door, roughness: 0.9 });
  const bloodMats = T.blood.map(
    (t) =>
      new THREE.MeshBasicMaterial({
        map: t,
        transparent: true,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -6,
        polygonOffsetUnits: -6,
        color: "#b0b0b0",
      })
  );
  const bloodGeo = new THREE.PlaneGeometry(1, 1);
  const bloodAt = (x: number, z: number, size: number) => {
    const m = new THREE.Mesh(bloodGeo, bloodMats[(rnd() * bloodMats.length) | 0]);
    m.rotation.x = -Math.PI / 2;
    m.rotation.z = rnd() * 6.28;
    m.scale.setScalar(size);
    m.position.set(x, 0.06, z);
    root.add(m);
  };

  for (const qx of [-1, 1]) {
    for (const qz of [-1, 1]) {
      for (let ix = 0; ix < 2; ix++) {
        for (let iz = 0; iz < 2; iz++) {
          const lx0 = 9 + ix * 26;
          const lz0 = 9 + iz * 26;
          const cx = qx * (lx0 + 11);
          const cz = qz * (lz0 + 11);
          const key = `${qx},${qz},${ix},${iz}`;
          const yard = forcedYards.has(key) || rnd() < 0.22;
          if (!yard) {
            const w = 12 + 4 * ((rnd() * 3) | 0);
            const d = 12 + 4 * ((rnd() * 3) | 0);
            const h = 8 + 4 * ((rnd() * 4) | 0);
            const bx = cx + (rnd() - 0.5) * (22 - w);
            const bz = cz + (rnd() - 0.5) * (22 - d);
            const side = facMats[(rnd() * facMats.length) | 0];
            const m = new THREE.Mesh(boxUV(w, h, d, 8), [side, side, roofMat, roofMat, side, side]);
            m.position.set(bx, h / 2, bz);
            m.castShadow = true;
            m.receiveShadow = true;
            root.add(m);
            addCollider(bx, bz, w, d, h, { building: true });
            // roof clutter
            if (rnd() > 0.4) {
              const rw = 2 + rnd() * 3;
              const r = new THREE.Mesh(boxUV(rw, 1.6, rw, 2), roofMat);
              r.position.set(bx + (rnd() - 0.5) * (w - 5), h + 0.8, bz + (rnd() - 0.5) * (d - 5));
              r.castShadow = true;
              root.add(r);
            }
            // door facing the nearest road
            const dx = Math.abs(bx) - w / 2 - 6;
            const dz = Math.abs(bz) - d / 2 - 6;
            const door = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 3.2), doorMat);
            let fx: number;
            let fz: number;
            if (dx < dz) {
              const nx = -Math.sign(bx);
              door.rotation.y = Math.atan2(nx, 0);
              fx = bx + nx * (w / 2 + 0.03);
              fz = bz + (rnd() - 0.5) * (d - 4);
              door.position.set(fx, 1.6, fz);
              bloodAt(fx + nx * 1.6, fz, 3 + rnd() * 2);
            } else {
              const nz = -Math.sign(bz);
              door.rotation.y = nz > 0 ? 0 : Math.PI;
              fx = bx + (rnd() - 0.5) * (w - 4);
              fz = bz + nz * (d / 2 + 0.03);
              door.position.set(fx, 1.6, fz);
              bloodAt(fx, fz + nz * 1.6, 3 + rnd() * 2);
            }
            root.add(door);
            // dumpster by the wall
            if (rnd() > 0.5) {
              const dm = createDumpster(T);
              const side2 = rnd() > 0.5 ? 1 : -1;
              placeRect(dm, 1.9, 1.0, 1.4, bx + side2 * (w / 2 + 1.4), bz + (rnd() - 0.5) * d * 0.6, Math.PI / 2, 0.3);
            }
          } else {
            const nProps = 5 + ((rnd() * 5) | 0);
            for (let k = 0; k < nProps * 3 && k < 40; k++) {
              const x = cx + (rnd() - 0.5) * 20;
              const z = cz + (rnd() - 0.5) * 20;
              const t = rnd();
              if (t < 0.25) {
                const c = createCar(T, (rnd() * 6) | 0);
                placeRect(c.group, c.w, c.d, c.h, x, z, rnd() > 0.5 ? 0 : Math.PI / 2, 0.8);
              } else if (t < 0.45) {
                const tr = createTree(T, rnd);
                if (!overlaps(x - 0.4, x + 0.4, z - 0.4, z + 0.4, 1.2)) {
                  tr.position.set(x, 0, z);
                  root.add(tr);
                  addCollider(x, z, 0.6, 0.6, 6);
                }
              } else if (t < 0.6) {
                const s = 0.9 + rnd() * 0.5;
                const cr = createCrate(T, s);
                if (placeRect(cr, s, s, s, x, z, 0, 0.4)) {
                  cr.rotation.y = rnd() * 0.6;
                  if (rnd() > 0.5) {
                    const c2 = createCrate(T, s * 0.8);
                    c2.position.set(x + 0.1, s, z);
                    c2.rotation.y = rnd();
                    root.add(c2);
                  }
                }
              } else if (t < 0.75) {
                addBarrel(x, z, rnd() > 0.45 ? "red" : rnd() > 0.5 ? "blue" : "grey");
                if (rnd() > 0.4) addBarrel(x + 0.7, z + 0.2, "red");
              } else if (t < 0.88) {
                const dm = createDumpster(T);
                placeRect(dm, 1.9, 1.0, 1.4, x, z, rnd() > 0.5 ? 0 : Math.PI / 2, 0.6);
              } else {
                const b = createBarrier(T);
                placeRect(b, 0.7, 2.6, 1, x, z, rnd() > 0.5 ? 0 : Math.PI / 2, 0.5);
              }
            }
            for (let k = 0; k < 3; k++) bloodAt(cx + (rnd() - 0.5) * 18, cz + (rnd() - 0.5) * 18, 2 + rnd() * 2);
          }
        }
      }
    }
  }

  /* ---- road clutter ---- */
  const bus = createBus(T);
  placeRect(bus.group, bus.w, bus.d, bus.h, -30, -2.8, Math.PI / 2, 0.5, false);
  const roadCars: [number, number, number][] = [
    [14, 2.6, 0],
    [24, -2.4, 1],
    [-12, 2.8, 2],
    [-44, 2.4, 3],
    [46, -2.6, 4],
    [2.6, 18, 5],
    [-2.5, 30, 0],
    [2.6, -22, 1],
    [-2.6, -40, 2],
    [2.4, 46, 3],
    [-8, -2.0, 4],
  ];
  for (const [x, z, ci] of roadCars) {
    const c = createCar(T, ci);
    const alongX = Math.abs(z) < 5;
    const rot = (alongX ? Math.PI / 2 : 0) + (rnd() > 0.5 ? Math.PI : 0);
    if (alongX && Math.abs(x) < 4) continue;
    placeRect(c.group, c.w, c.d, c.h, x, z, alongX ? Math.PI / 2 : 0, 0.3, false);
    c.group.rotation.y = rot;
  }
  // military-style blockade
  for (let i = 0; i < 5; i++) {
    const b = createBarrier(T);
    placeRect(b, 0.7, 2.6, 1, 50, -5 + i * 2.6, 0, 0.1, false);
  }
  for (let i = 0; i < 4; i++) {
    const b = createBarrier(T);
    placeRect(b, 0.7, 2.6, 1, -4 + i * 2.6, -50, Math.PI / 2, 0.1, false);
  }

  /* ---- road debris ---- */
  addBarrel(10, -3, "red");
  addBarrel(10.8, -3.3, "red");
  addBarrel(-3, 14, "red");
  addBarrel(-3.8, 14.3, "red");
  addBarrel(26, 4, "red");
  addBarrel(-22, -4.5, "red");
  addBarrel(4, -34, "red");
  addBarrel(-38, 3.5, "red");
  addFire(12, 5.2, true);
  addFire(-14, -5.4, true);
  addFire(30, -4.8, false);
  addFire(-5, 26, false);
  addFire(5.4, -30, false);
  addFire(-50, 4.5, false);
  for (const [x, z] of [
    [8, 6],
    [-10, -3],
    [22, 8],
    [0, 12],
    [-26, 2],
    [3, -14],
    [34, -2],
    [-6, -24],
    [0, 36],
    [-34, -3],
  ]) {
    bloodAt(x, z, 2.5 + rnd() * 2.5);
  }

  return { colliders, barrels, fires, lampLights, shotgunPos, riflePos };
}
