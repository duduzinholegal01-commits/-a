import * as THREE from "three";
import type { Textures } from "./textures";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";

export type ZType = "walker" | "runner" | "brute";
export type GunKind = "pistol" | "shotgun" | "rifle";

const geoCache = new Map<string, THREE.BufferGeometry>();
export function box(w: number, h: number, d: number) {
  const k = `b${w},${h},${d}`;
  let g = geoCache.get(k);
  if (!g) {
    g = new THREE.BoxGeometry(w, h, d);
    geoCache.set(k, g);
  }
  return g;
}

/** Box with UVs scaled in world units (tile = metres per texture repeat) */
export function boxUV(w: number, h: number, d: number, tile = 4) {
  const g = new THREE.BoxGeometry(w, h, d);
  const uv = g.attributes.uv as THREE.BufferAttribute;
  const dims = [
    [d, h],
    [d, h],
    [w, d],
    [w, d],
    [w, h],
    [w, h],
  ];
  for (let f = 0; f < 6; f++) {
    for (let v = 0; v < 4; v++) {
      const i = f * 4 + v;
      uv.setXY(i, (uv.getX(i) * dims[f][0]) / tile, (uv.getY(i) * dims[f][1]) / tile);
    }
  }
  return g;
}

export function planeUV(w: number, h: number, tileW: number, tileH = tileW) {
  const g = new THREE.PlaneGeometry(w, h);
  const uv = g.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, (uv.getX(i) * w) / tileW, (uv.getY(i) * h) / tileH);
  return g;
}

function mesh(g: THREE.BufferGeometry, m: THREE.Material | THREE.Material[], cast = true) {
  const o = new THREE.Mesh(g, m);
  o.castShadow = cast;
  o.receiveShadow = true;
  return o;
}


/** Merge all single-material meshes of a group into one mesh per material (fewer draw calls). */
export function bake<T extends THREE.Object3D>(group: T): T {
  group.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(group.matrixWorld).invert();
  const buckets = new Map<THREE.Material, THREE.BufferGeometry[]>();
  const toRemove: THREE.Mesh[] = [];
  group.traverse((o) => {
    const m = o as THREE.Mesh;
    if (!m.isMesh || Array.isArray(m.material)) return;
    const g = m.geometry.clone();
    g.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inv, m.matrixWorld));
    const list = buckets.get(m.material) || [];
    list.push(g);
    buckets.set(m.material, list);
    toRemove.push(m);
  });
  for (const m of toRemove) m.parent?.remove(m);
  buckets.forEach((geos, mat) => {
    const merged = geos.length === 1 ? geos[0] : mergeGeometries(geos, false);
    if (!merged) return;
    const mm = new THREE.Mesh(merged, mat);
    mm.castShadow = true;
    mm.receiveShadow = true;
    group.add(mm);
  });
  return group;
}

/* ------------------------------------------------------------------ */
/* ZOMBIES                                                              */
/* ------------------------------------------------------------------ */

export interface ZRig {
  group: THREE.Group;
  lean: THREE.Group;
  head: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  mats: THREE.MeshStandardMaterial[];
  meshes: THREE.Mesh[];
}

const SHIRTS = ["#6b7f9a", "#8a4b3a", "#5e6b4a", "#8d8d86", "#3d4f6b", "#7a6a3a", "#5a3a5a", "#9a9a9a"];
const PANTS = ["#3b3f4a", "#4a3f33", "#2d3a3f", "#44484a", "#2a2a33"];

export function createZombie(type: ZType, T: Textures, rnd: () => number): ZRig {
  const pick = <A,>(a: A[]) => a[(rnd() * a.length) | 0];
  const skinMap = pick(T.skins);
  const mk = (map: THREE.Texture | null, color = "#ffffff", rough = 0.92) =>
    new THREE.MeshStandardMaterial({ map, color, roughness: rough, metalness: 0, emissive: 0x000000 });
  const skin = mk(skinMap, type === "brute" ? "#c8c0b8" : "#ffffff");
  const face = mk(type === "runner" ? T.faceRed : T.faceYellow, type === "brute" ? "#c8c0b8" : "#ffffff");
  const shirt = mk(pick(T.cloth), type === "brute" ? "#4a3a30" : pick(SHIRTS));
  const pants = mk(T.cloth[0], pick(PANTS));
  const hair = mk(null, pick(["#1a1410", "#2a2018", "#0e0e0e", "#4a4036", "#555"]), 1);
  const mats = [skin, face, shirt, pants, hair];

  const group = new THREE.Group();
  const meshes: THREE.Mesh[] = [];
  const add = (parent: THREE.Object3D, g: THREE.BufferGeometry, m: THREE.Material | THREE.Material[], x: number, y: number, z: number, part: string) => {
    const o = mesh(g, m);
    o.position.set(x, y, z);
    o.userData.part = part;
    parent.add(o);
    meshes.push(o);
    return o;
  };

  const mkLeg = (x: number) => {
    const leg = new THREE.Group();
    leg.position.set(x, 0.8, 0);
    add(leg, box(0.22, 0.8, 0.24), pants, 0, -0.4, 0, "body");
    group.add(leg);
    return leg;
  };
  const legL = mkLeg(-0.13);
  const legR = mkLeg(0.13);

  const lean = new THREE.Group();
  lean.position.set(0, 0.8, 0);
  group.add(lean);
  add(lean, box(0.52, 0.7, 0.26), type === "brute" ? skin : shirt, 0, 0.35, 0, "body");

  const head = new THREE.Group();
  head.position.set(0, 0.72, 0);
  lean.add(head);
  add(head, box(0.3, 0.32, 0.3), [skin, skin, skin, skin, face, skin], 0, 0.17, 0, "head");
  if (rnd() > 0.35) add(head, box(0.32, 0.1, 0.32), hair, 0, 0.32, -0.01, "head");
  add(head, box(0.32, 0.22, 0.1), hair, 0, 0.22, -0.12, "head");

  const mkArm = (x: number) => {
    const arm = new THREE.Group();
    arm.position.set(x, 0.64, 0);
    add(arm, box(0.15, 0.36, 0.15), type === "brute" ? skin : shirt, 0, -0.18, 0, "body");
    add(arm, box(0.13, 0.36, 0.13), skin, 0, -0.54, 0, "body");
    lean.add(arm);
    return arm;
  };
  const armL = mkArm(-0.35);
  const armR = mkArm(0.35);

  group.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      (o as THREE.Mesh).castShadow = true;
    }
  });

  if (type === "brute") {
    group.scale.set(1.6, 1.5, 1.45);
  } else if (type === "runner") {
    const s = 0.93 + rnd() * 0.05;
    group.scale.set(s * 0.92, s, s * 0.92);
  } else {
    const s = 0.94 + rnd() * 0.12;
    group.scale.set(s, s, s);
  }

  return { group, lean, head, armL, armR, legL, legR, mats, meshes };
}

/* ------------------------------------------------------------------ */
/* WEAPONS (view-models)                                                */
/* ------------------------------------------------------------------ */

interface GunMats {
  metal: THREE.MeshStandardMaterial;
  dark: THREE.MeshStandardMaterial;
  wood: THREE.MeshStandardMaterial;
  sleeve: THREE.MeshStandardMaterial;
  skin: THREE.MeshStandardMaterial;
  lens: THREE.MeshStandardMaterial;
}
const gunMatCache = new WeakMap<Textures, GunMats>();
function gunMats(T: Textures): GunMats {
  let m = gunMatCache.get(T);
  if (!m) {
    m = {
      metal: new THREE.MeshStandardMaterial({ map: T.metal, color: "#9a9ea6", roughness: 0.45, metalness: 0.35 }),
      dark: new THREE.MeshStandardMaterial({ color: "#1b1c1e", roughness: 0.55, metalness: 0.3 }),
      wood: new THREE.MeshStandardMaterial({ map: T.wood, color: "#b08a66", roughness: 0.7 }),
      sleeve: new THREE.MeshStandardMaterial({ map: T.cloth[0], color: "#3c4a30", roughness: 0.95 }),
      skin: new THREE.MeshStandardMaterial({ color: "#c49a78", roughness: 0.85 }),
      lens: new THREE.MeshStandardMaterial({ color: "#2a5a8a", roughness: 0.1, metalness: 0.8, emissive: "#0a1a2a" }),
    };
    gunMatCache.set(T, m);
  }
  return m;
}

const UP = new THREE.Vector3(0, 0, 1);
function limb(parent: THREE.Object3D, a: [number, number, number], b: [number, number, number], w: number, mat: THREE.Material) {
  const va = new THREE.Vector3(...a);
  const vb = new THREE.Vector3(...b);
  const len = va.distanceTo(vb);
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, w, len), mat);
  m.position.copy(va).add(vb).multiplyScalar(0.5);
  m.quaternion.setFromUnitVectors(UP, vb.clone().sub(va).normalize());
  parent.add(m);
  return m;
}

function cyl(parent: THREE.Object3D, r: number, len: number, pos: [number, number, number], mat: THREE.Material, rx = Math.PI / 2) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 12), mat);
  m.rotation.x = rx;
  m.position.set(...pos);
  parent.add(m);
  return m;
}

function bx(parent: THREE.Object3D, w: number, h: number, d: number, pos: [number, number, number], mat: THREE.Material, rx = 0) {
  const m = new THREE.Mesh(box(w, h, d), mat);
  m.position.set(...pos);
  m.rotation.x = rx;
  parent.add(m);
  return m;
}

export interface GunModel {
  group: THREE.Group;
  muzzle: THREE.Vector3;
  pump: THREE.Object3D | null;
}

export function buildGun(kind: GunKind, T: Textures, hands = true): GunModel {
  const M = gunMats(T);
  const g = new THREE.Group();
  let pump: THREE.Object3D | null = null;
  let muzzle = new THREE.Vector3();
  if (kind === "pistol") {
    bx(g, 0.05, 0.055, 0.27, [0, 0.035, -0.1], M.metal);
    bx(g, 0.044, 0.04, 0.2, [0, -0.005, -0.07], M.dark);
    bx(g, 0.046, 0.125, 0.065, [0, -0.07, 0.03], M.dark, 0.22);
    bx(g, 0.012, 0.02, 0.012, [0, 0.07, -0.22], M.dark);
    bx(g, 0.02, 0.018, 0.012, [0, 0.07, 0.03], M.dark);
    bx(g, 0.01, 0.03, 0.05, [0, -0.04, -0.06], M.dark);
    muzzle = new THREE.Vector3(0, 0.035, -0.25);
    if (hands) {
      bx(g, 0.065, 0.07, 0.09, [0, -0.06, 0.03], M.skin);
      limb(g, [0.01, -0.07, 0.06], [0.16, -0.32, 0.6], 0.085, M.sleeve);
      bx(g, 0.05, 0.06, 0.08, [-0.045, -0.08, -0.01], M.skin);
      limb(g, [-0.05, -0.09, 0.02], [-0.22, -0.32, 0.55], 0.085, M.sleeve);
    }
  } else if (kind === "shotgun") {
    cyl(g, 0.017, 0.8, [0, 0.035, -0.4], M.metal);
    cyl(g, 0.015, 0.62, [0, -0.0, -0.31], M.dark);
    bx(g, 0.058, 0.085, 0.26, [0, 0.0, 0.0], M.metal);
    pump = bx(g, 0.062, 0.05, 0.19, [0, -0.012, -0.34], M.wood);
    bx(g, 0.05, 0.1, 0.32, [0, -0.04, 0.27], M.wood, -0.1);
    bx(g, 0.012, 0.02, 0.012, [0, 0.062, -0.78], M.dark);
    bx(g, 0.02, 0.012, 0.1, [0, 0.055, -0.05], M.dark);
    muzzle = new THREE.Vector3(0, 0.035, -0.82);
    if (hands) {
      bx(g, 0.065, 0.07, 0.09, [0, -0.07, 0.08], M.skin);
      limb(g, [0.01, -0.08, 0.1], [0.17, -0.32, 0.62], 0.09, M.sleeve);
      const lh = new THREE.Group();
      bx(lh, 0.07, 0.065, 0.1, [0, -0.04, 0], M.skin);
      limb(lh, [0, -0.045, 0.04], [-0.17, -0.3, 0.52], 0.09, M.sleeve);
      lh.position.set(0, 0, -0.36);
      g.add(lh);
      pump.userData.hand = lh;
    }
  } else {
    bx(g, 0.052, 0.09, 0.42, [0, 0, -0.05], M.dark);
    bx(g, 0.04, 0.03, 0.4, [0, 0.055, -0.05], M.metal);
    cyl(g, 0.014, 0.42, [0, 0.025, -0.52], M.metal);
    bx(g, 0.062, 0.065, 0.28, [0, -0.005, -0.36], M.wood);
    bx(g, 0.04, 0.17, 0.07, [0, -0.12, -0.08], M.dark, 0.25);
    bx(g, 0.046, 0.1, 0.3, [0, -0.04, 0.28], M.wood, -0.08);
    bx(g, 0.045, 0.11, 0.06, [0, -0.08, 0.1], M.dark, 0.2);
    cyl(g, 0.026, 0.2, [0, 0.1, -0.05], M.dark);
    cyl(g, 0.027, 0.01, [0, 0.1, -0.15], M.lens);
    bx(g, 0.012, 0.04, 0.012, [0, 0.07, -0.05], M.dark);
    bx(g, 0.012, 0.03, 0.012, [0, 0.055, -0.7], M.dark);
    muzzle = new THREE.Vector3(0, 0.025, -0.76);
    if (hands) {
      bx(g, 0.065, 0.07, 0.09, [0, -0.1, 0.1], M.skin);
      limb(g, [0.01, -0.1, 0.12], [0.17, -0.34, 0.64], 0.09, M.sleeve);
      bx(g, 0.07, 0.065, 0.1, [0, -0.045, -0.36], M.skin);
      limb(g, [0, -0.05, -0.32], [-0.17, -0.3, 0.2], 0.09, M.sleeve);
    }
  }
  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) o.frustumCulled = false;
  });
  return { group: g, muzzle, pump };
}

export function buildCrowbar(T: Textures) {
  const M = gunMats(T);
  const g = new THREE.Group();
  const steel = new THREE.MeshStandardMaterial({ color: "#7a1a14", roughness: 0.5, metalness: 0.4 });
  cyl(g, 0.016, 0.8, [0, 0, -0.2], steel);
  const hook = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.016, 8, 12, Math.PI * 0.9), steel);
  hook.position.set(0, 0.06, -0.6);
  hook.rotation.y = Math.PI / 2;
  g.add(hook);
  bx(g, 0.065, 0.07, 0.09, [0, -0.01, 0.1], M.skin);
  limb(g, [0.02, -0.02, 0.12], [0.18, -0.3, 0.6], 0.09, M.sleeve);
  bx(g, 0.065, 0.07, 0.09, [0, -0.01, 0.0], M.skin);
  limb(g, [-0.02, -0.02, 0.02], [-0.2, -0.3, 0.55], 0.09, M.sleeve);
  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) o.frustumCulled = false;
  });
  return g;
}

/* ------------------------------------------------------------------ */
/* PROPS                                                                */
/* ------------------------------------------------------------------ */

const glassMat = new THREE.MeshStandardMaterial({ color: "#0a1015", roughness: 0.15, metalness: 0.6 });
const blackMat = new THREE.MeshStandardMaterial({ color: "#101010", roughness: 0.9 });
const lightMat = new THREE.MeshStandardMaterial({ color: "#aaa", roughness: 0.3 });
const tailMat = new THREE.MeshStandardMaterial({ color: "#600", emissive: "#300", roughness: 0.4 });

export function createCar(T: Textures, idx: number) {
  const paint = new THREE.MeshStandardMaterial({ map: T.paints[idx % T.paints.length], roughness: 0.55, metalness: 0.25 });
  const g = new THREE.Group();
  const body = mesh(boxUV(1.9, 0.65, 4.4, 2), paint);
  body.position.y = 0.65;
  g.add(body);
  const hood = mesh(boxUV(1.85, 0.12, 1.3, 2), paint);
  hood.position.set(0, 1.0, 1.55);
  g.add(hood);
  const cabin = mesh(box(1.66, 0.62, 2.3), [glassMat, glassMat, paint, paint, glassMat, glassMat]);
  cabin.position.set(0, 1.28, -0.35);
  g.add(cabin);
  for (const [x, z] of [
    [-0.95, 1.4],
    [0.95, 1.4],
    [-0.95, -1.4],
    [0.95, -1.4],
  ]) {
    const w = mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.25, 14), blackMat);
    w.rotation.z = Math.PI / 2;
    w.position.set(x, 0.36, z);
    g.add(w);
  }
  for (const x of [-0.65, 0.65]) {
    const hl = mesh(box(0.3, 0.14, 0.05), lightMat, false);
    hl.position.set(x, 0.78, 2.2);
    g.add(hl);
    const tl = mesh(box(0.3, 0.12, 0.05), tailMat, false);
    tl.position.set(x, 0.8, -2.2);
    g.add(tl);
  }
  bake(g);
  return { group: g, w: 1.9, d: 4.4, h: 1.6 };
}

export function createBus(T: Textures) {
  const side = new THREE.MeshStandardMaterial({ map: T.bus, roughness: 0.7, metalness: 0.15 });
  const paint = new THREE.MeshStandardMaterial({ map: T.paints[5], roughness: 0.7, metalness: 0.15 });
  const roof = new THREE.MeshStandardMaterial({ map: T.concrete, color: "#aaa", roughness: 0.9 });
  const g = new THREE.Group();
  const body = mesh(new THREE.BoxGeometry(2.6, 3.0, 10.5), [side, side, roof, blackMat, paint, paint]);
  body.position.y = 2.0;
  g.add(body);
  for (const [x, z] of [
    [-1.2, 3.3],
    [1.2, 3.3],
    [-1.2, -3.3],
    [1.2, -3.3],
  ]) {
    const w = mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.35, 16), blackMat);
    w.rotation.z = Math.PI / 2;
    w.position.set(x, 0.55, z);
    g.add(w);
  }
  bake(g);
  return { group: g, w: 2.6, d: 10.5, h: 3.5 };
}

export function createBarrel(T: Textures, kind: "red" | "blue" | "grey") {
  const tex = kind === "red" ? T.barrelRed : kind === "blue" ? T.barrelBlue : T.barrelGrey;
  const side = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.5, metalness: 0.4 });
  const cap = new THREE.MeshStandardMaterial({ color: "#2a2a2a", roughness: 0.6, metalness: 0.5 });
  const m = mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.95, 18), [side, cap, cap]);
  m.position.y = 0.475;
  const g = new THREE.Group();
  g.add(m);
  return g;
}

export function createCrate(T: Textures, size: number) {
  const m = new THREE.MeshStandardMaterial({ map: T.crate, roughness: 0.85 });
  const o = mesh(new THREE.BoxGeometry(size, size, size), m);
  o.position.y = size / 2;
  const g = new THREE.Group();
  g.add(o);
  return g;
}

export function createDumpster(T: Textures) {
  const paint = new THREE.MeshStandardMaterial({ map: T.paints[4], roughness: 0.6, metalness: 0.3 });
  const g = new THREE.Group();
  const b = mesh(boxUV(1.9, 1.2, 1.0, 2), paint);
  b.position.y = 0.7;
  g.add(b);
  const lid = mesh(box(1.96, 0.08, 1.06), blackMat);
  lid.position.set(0, 1.34, 0);
  lid.rotation.x = 0.05;
  g.add(lid);
  for (const x of [-0.8, 0.8]) {
    const w = mesh(box(0.1, 0.2, 0.1), blackMat);
    w.position.set(x, 0.1, 0);
    g.add(w);
  }
  return bake(g);
}

export function createBarrier(T: Textures) {
  const m = new THREE.MeshStandardMaterial({ map: T.concrete, color: "#b0b0aa", roughness: 0.95 });
  const g = new THREE.Group();
  const base = mesh(boxUV(0.7, 0.4, 2.6, 2.5), m);
  base.position.y = 0.2;
  g.add(base);
  const top = mesh(boxUV(0.34, 0.6, 2.6, 2.5), m);
  top.position.y = 0.7;
  g.add(top);
  return bake(g);
}

export function createTree(T: Textures, rnd: () => number) {
  const bark = new THREE.MeshStandardMaterial({ map: T.bark, roughness: 1 });
  const g = new THREE.Group();
  const h = 4.5 + rnd() * 2.5;
  const trunk = mesh(new THREE.CylinderGeometry(0.14, 0.3, h, 8), bark);
  trunk.position.y = h / 2;
  g.add(trunk);
  const branch = (parent: THREE.Object3D, y: number, len: number, r: number, depth: number, rotY: number) => {
    const piv = new THREE.Group();
    piv.position.y = y;
    piv.rotation.y = rotY;
    const lean = 0.7 + rnd() * 0.6;
    const inner = new THREE.Group();
    inner.rotation.z = lean;
    const b = mesh(new THREE.CylinderGeometry(r * 0.5, r, len, 6), bark);
    b.position.y = len / 2;
    inner.add(b);
    piv.add(inner);
    parent.add(piv);
    if (depth > 0) {
      const sub = new THREE.Group();
      sub.position.y = len;
      inner.add(sub);
      for (let i = 0; i < 2; i++) branch(sub, 0, len * 0.65, r * 0.55, depth - 1, rnd() * 6.28);
    }
  };
  const n = 4 + ((rnd() * 3) | 0);
  for (let i = 0; i < n; i++) {
    branch(g, h * (0.45 + rnd() * 0.5), 1.3 + rnd() * 0.9, 0.09, 2, rnd() * 6.28);
  }
  return bake(g);
}

export function createLamp(T: Textures) {
  const pole = new THREE.MeshStandardMaterial({ map: T.metal, color: "#6a6e70", roughness: 0.6, metalness: 0.5 });
  const bulb = new THREE.MeshBasicMaterial({ color: "#ffd9a0" });
  const g = new THREE.Group();
  const p = mesh(new THREE.CylinderGeometry(0.07, 0.11, 6.4, 8), pole);
  p.position.y = 3.2;
  g.add(p);
  const arm = mesh(box(1.3, 0.09, 0.09), pole);
  arm.position.set(0.6, 6.35, 0);
  g.add(arm);
  const hood = mesh(box(0.55, 0.08, 0.3), pole);
  hood.position.set(1.15, 6.4, 0);
  g.add(hood);
  const b = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 8), bulb);
  b.position.set(1.15, 6.28, 0);
  g.add(b);
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow, color: "#ffc880", blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.8, fog: false }));
  glow.scale.setScalar(3.2);
  glow.position.set(1.15, 6.25, 0);
  g.add(glow);
  return { group: g, bulbPos: new THREE.Vector3(1.15, 6.1, 0) };
}

/* ------------------------------------------------------------------ */
/* PICKUPS                                                              */
/* ------------------------------------------------------------------ */

export type PickupKind = "ammo" | "health" | "shotgun" | "rifle";

function labelSprite(text: string, color: string) {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 64;
  const ctx = c.getContext("2d")!;
  ctx.font = "bold 34px Arial, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.shadowColor = color;
  ctx.shadowBlur = 12;
  ctx.fillStyle = color;
  ctx.fillText(text, 128, 34);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthWrite: false, fog: false }));
  s.scale.set(2, 0.5, 1);
  return s;
}

export function createPickup(kind: PickupKind, T: Textures) {
  const root = new THREE.Group();
  const float = new THREE.Group();
  root.add(float);
  let color = "#ffd34a";
  let label = "";
  if (kind === "ammo") {
    const m = new THREE.MeshStandardMaterial({ map: T.ammo, roughness: 0.7, emissive: "#2a2a10" });
    const b = mesh(box(0.55, 0.34, 0.4), m);
    float.add(b);
    color = "#ffd34a";
    label = "MUNIÇÃO";
  } else if (kind === "health") {
    const m = new THREE.MeshStandardMaterial({ map: T.med, roughness: 0.6, emissive: "#201010" });
    const b = mesh(box(0.5, 0.38, 0.4), m);
    float.add(b);
    color = "#5dff7a";
    label = "KIT MÉDICO";
  } else {
    const gm = buildGun(kind, T, false);
    gm.group.scale.setScalar(1.5);
    gm.group.rotation.y = Math.PI / 2;
    gm.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        (o as THREE.Mesh).castShadow = false;
      }
    });
    float.add(gm.group);
    color = "#5ac8ff";
    label = kind === "shotgun" ? "ESPINGARDA" : "RIFLE";
  }
  float.position.y = 1.0;
  const beam = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.28, 16, 14, 1, true),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.16, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false })
  );
  beam.position.y = 8;
  root.add(beam);
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow, color, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.9 }));
  glow.scale.setScalar(2.2);
  glow.position.y = 0.4;
  root.add(glow);
  const lab = labelSprite(label, color);
  lab.position.y = 1.9;
  root.add(lab);
  return { root, float };
}
