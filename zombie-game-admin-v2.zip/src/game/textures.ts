import * as THREE from "three";

export function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type Ctx = CanvasRenderingContext2D;
type R = () => number;

function mk(w: number, h = w): [HTMLCanvasElement, Ctx] {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return [c, c.getContext("2d")!];
}

function grain(ctx: Ctx, w: number, h: number, amt: number, r: R) {
  const id = ctx.getImageData(0, 0, w, h);
  const d = id.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (r() - 0.5) * amt;
    d[i] += n;
    d[i + 1] += n;
    d[i + 2] += n;
  }
  ctx.putImageData(id, 0, 0);
}

function soft(
  ctx: Ctx,
  w: number,
  h: number,
  r: R,
  count: number,
  colors: string[],
  rmin: number,
  rmax: number,
  a: number,
  wrap = true
) {
  const offs = wrap ? [-1, 0, 1] : [0];
  for (let i = 0; i < count; i++) {
    const x = r() * w;
    const y = r() * h;
    const rad = rmin + r() * (rmax - rmin);
    const col = colors[(r() * colors.length) | 0];
    for (const ox of offs) {
      for (const oy of offs) {
        const cx = x + ox * w;
        const cy = y + oy * h;
        if (cx + rad < 0 || cx - rad > w || cy + rad < 0 || cy - rad > h) continue;
        const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
        g.addColorStop(0, `rgba(${col},${a})`);
        g.addColorStop(1, `rgba(${col},0)`);
        ctx.fillStyle = g;
        ctx.fillRect(cx - rad, cy - rad, rad * 2, rad * 2);
      }
    }
  }
}

function cracks(ctx: Ctx, w: number, h: number, r: R, count: number, color: string, lw = 1.2) {
  ctx.strokeStyle = color;
  ctx.lineWidth = lw;
  for (let i = 0; i < count; i++) {
    let x = r() * w;
    let y = r() * h;
    ctx.beginPath();
    ctx.moveTo(x, y);
    const n = 6 + ((r() * 14) | 0);
    let a = r() * Math.PI * 2;
    for (let k = 0; k < n; k++) {
      a += (r() - 0.5) * 1.2;
      x += Math.cos(a) * (6 + r() * 14);
      y += Math.sin(a) * (6 + r() * 14);
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
}

function toTex(c: HTMLCanvasElement, opts: { repeat?: boolean; srgb?: boolean } = {}) {
  const t = new THREE.CanvasTexture(c);
  if (opts.repeat !== false) {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
  }
  t.colorSpace = opts.srgb === false ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

/* ---------- Individual textures ---------- */

function groundTex() {
  const s = 512;
  const r = rng(11);
  const [c, ctx] = mk(s);
  ctx.fillStyle = "#2c3020";
  ctx.fillRect(0, 0, s, s);
  soft(ctx, s, s, r, 50, ["58,52,34", "36,52,26", "24,26,20", "70,62,44", "44,40,28"], 30, 90, 0.5);
  // grass blades
  for (let i = 0; i < 2600; i++) {
    const x = r() * s;
    const y = r() * s;
    const g = 40 + r() * 50;
    ctx.strokeStyle = `rgba(${g * 0.7},${g + 20},${g * 0.4},0.55)`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (r() - 0.5) * 5, y - 4 - r() * 8);
    ctx.stroke();
  }
  // pebbles
  for (let i = 0; i < 160; i++) {
    ctx.fillStyle = `rgba(${90 + r() * 50},${85 + r() * 40},${70 + r() * 30},0.6)`;
    ctx.beginPath();
    ctx.arc(r() * s, r() * s, 1 + r() * 2.2, 0, 7);
    ctx.fill();
  }
  grain(ctx, s, s, 34, r);
  return toTex(c);
}

function asphaltTex() {
  const s = 512;
  const r = rng(23);
  const [c, ctx] = mk(s);
  ctx.fillStyle = "#2b2c30";
  ctx.fillRect(0, 0, s, s);
  soft(ctx, s, s, r, 40, ["18,18,20", "52,52,56", "30,28,26", "12,12,14"], 25, 80, 0.45);
  for (let i = 0; i < 1800; i++) {
    const v = 50 + r() * 90;
    ctx.fillStyle = `rgba(${v},${v},${v + 4},0.4)`;
    ctx.fillRect(r() * s, r() * s, 1 + r() * 2, 1 + r() * 2);
  }
  cracks(ctx, s, s, r, 7, "rgba(8,8,10,0.9)", 1.6);
  cracks(ctx, s, s, r, 10, "rgba(8,8,10,0.6)", 0.9);
  grain(ctx, s, s, 28, r);
  return toTex(c);
}

function roadLineTex() {
  const [c, ctx] = mk(256, 32);
  const r = rng(5);
  ctx.fillStyle = "#c9a82a";
  ctx.fillRect(0, 4, 128, 24);
  ctx.globalCompositeOperation = "destination-out";
  for (let i = 0; i < 260; i++) {
    ctx.fillStyle = `rgba(0,0,0,${0.3 + r() * 0.7})`;
    ctx.fillRect(r() * 128, r() * 32, 1 + r() * 5, 1 + r() * 3);
  }
  return toTex(c);
}

function concreteTex() {
  const s = 512;
  const r = rng(31);
  const [c, ctx] = mk(s);
  ctx.fillStyle = "#6f716e";
  ctx.fillRect(0, 0, s, s);
  soft(ctx, s, s, r, 45, ["90,92,88", "52,54,52", "78,74,66", "40,40,38"], 30, 100, 0.4);
  // panel seams
  ctx.strokeStyle = "rgba(25,25,25,0.7)";
  ctx.lineWidth = 3;
  ctx.strokeRect(0, 0, s, s);
  ctx.beginPath();
  ctx.moveTo(0, s / 2);
  ctx.lineTo(s, s / 2);
  ctx.stroke();
  // rain streaks
  for (let i = 0; i < 30; i++) {
    const x = r() * s;
    const g = ctx.createLinearGradient(0, 0, 0, s);
    g.addColorStop(0, "rgba(20,22,20,0)");
    g.addColorStop(0.3 + r() * 0.3, `rgba(20,22,20,${0.15 + r() * 0.2})`);
    g.addColorStop(1, "rgba(20,22,20,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x, 0, 2 + r() * 6, s);
  }
  cracks(ctx, s, s, r, 6, "rgba(15,15,15,0.7)", 1.3);
  grain(ctx, s, s, 40, r);
  return toTex(c);
}

function drawBricks(ctx: Ctx, w: number, h: number, rows: number, cols: number, r: R, hue: number) {
  ctx.fillStyle = "#8d877c";
  ctx.fillRect(0, 0, w, h);
  const bh = h / rows;
  const bw = w / cols;
  for (let j = 0; j < rows; j++) {
    const off = j % 2 ? bw / 2 : 0;
    for (let i = -1; i <= cols; i++) {
      const l = 24 + r() * 16;
      const sat = 28 + r() * 22;
      ctx.fillStyle = `hsl(${hue + r() * 10 - 4},${sat}%,${l}%)`;
      ctx.fillRect(i * bw + off + 1, j * bh + 1, bw - 2, bh - 2);
    }
  }
}

function drawWindow(ctx: Ctx, x: number, y: number, w: number, h: number, mode: string, r: R, emissive = false) {
  if (emissive) {
    if (mode !== "lit") return;
    const g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, "#ffb55a");
    g.addColorStop(1, "#ff8a2a");
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = "#000";
    ctx.fillRect(x + w / 2 - 3, y, 6, h);
    ctx.fillRect(x, y + h * 0.45, w, 5);
    // silhouette of curtain
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(x, y, w * 0.22, h);
    return;
  }
  ctx.fillStyle = "#1b1b1a";
  ctx.fillRect(x - 9, y - 9, w + 18, h + 18);
  ctx.fillStyle = "#a5a59d";
  ctx.fillRect(x - 6, y - 6, w + 12, h + 12);
  ctx.fillStyle = "#8a8a82";
  ctx.fillRect(x - 14, y + h + 6, w + 28, 11);
  ctx.fillStyle = "#4b4b46";
  ctx.fillRect(x - 14, y + h + 17, w + 28, 4);
  const g = ctx.createLinearGradient(x, y, x + w, y + h);
  g.addColorStop(0, "#0a1218");
  g.addColorStop(0.5, "#223540");
  g.addColorStop(1, "#0c161d");
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);
  if (mode === "lit") {
    ctx.fillStyle = "rgba(255,170,70,0.75)";
    ctx.fillRect(x, y, w, h);
  } else if (mode === "curtain") {
    ctx.fillStyle = `hsl(${r() * 360},30%,32%)`;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + w * 0.45, y);
    ctx.lineTo(x + w * 0.3, y + h * 0.7);
    ctx.lineTo(x, y + h * 0.85);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x + w, y);
    ctx.lineTo(x + w * 0.62, y);
    ctx.lineTo(x + w * 0.78, y + h * 0.55);
    ctx.lineTo(x + w, y + h * 0.6);
    ctx.fill();
  } else if (mode === "broken") {
    ctx.fillStyle = "#000";
    ctx.beginPath();
    ctx.moveTo(x + w * 0.1, y);
    ctx.lineTo(x + w * 0.9, y + h * 0.1);
    ctx.lineTo(x + w * 0.5, y + h * 0.55);
    ctx.lineTo(x + w * 0.8, y + h);
    ctx.lineTo(x, y + h);
    ctx.fill();
    ctx.strokeStyle = "rgba(220,235,240,0.5)";
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 9; i++) {
      ctx.beginPath();
      ctx.moveTo(x + w * 0.55, y + h * 0.5);
      ctx.lineTo(x + r() * w, y + r() * h);
      ctx.stroke();
    }
  }
  ctx.fillStyle = "#8f8f89";
  ctx.fillRect(x + w / 2 - 3, y, 6, h);
  ctx.fillRect(x, y + h * 0.45, w, 5);
  if (mode === "boards") {
    for (let i = 0; i < 4; i++) {
      const py = y + 8 + i * (h / 4);
      ctx.save();
      ctx.translate(x + w / 2, py + 14);
      ctx.rotate((r() - 0.5) * 0.18);
      ctx.fillStyle = `hsl(28,${30 + r() * 15}%,${22 + r() * 12}%)`;
      ctx.fillRect(-w / 2 - 14, -13, w + 28, 26);
      ctx.fillStyle = "#1a1208";
      ctx.fillRect(-w / 2 - 8, -2, 4, 4);
      ctx.fillRect(w / 2 + 4, -2, 4, 4);
      ctx.restore();
    }
  }
}

function facade(kind: "brick" | "plaster" | "concrete", seed: number, base: string, hue = 10) {
  const s = 1024;
  const r = rng(seed);
  const [c, ctx] = mk(s);
  const [ce, ectx] = mk(s);
  ectx.fillStyle = "#000";
  ectx.fillRect(0, 0, s, s);
  if (kind === "brick") {
    drawBricks(ctx, s, s, 64, 32, r, hue);
  } else if (kind === "plaster") {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, s, s);
    soft(ctx, s, s, r, 40, ["255,255,240", "40,35,30", "90,80,60"], 40, 130, 0.22);
    // peeling patches showing brick
    for (let i = 0; i < 7; i++) {
      const px = r() * (s - 120);
      const py = r() * (s - 120);
      ctx.save();
      ctx.beginPath();
      ctx.rect(px, py, 40 + r() * 80, 30 + r() * 80);
      ctx.clip();
      drawBricks(ctx, s, s, 64, 32, r, 12);
      ctx.restore();
    }
  } else {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, s, s);
    soft(ctx, s, s, r, 50, ["120,122,118", "50,52,50", "70,66,58"], 40, 140, 0.3);
    ctx.strokeStyle = "rgba(20,20,20,0.6)";
    ctx.lineWidth = 3;
    for (let i = 0; i <= 4; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 256, 0);
      ctx.lineTo(i * 256, s);
      ctx.stroke();
    }
    for (let j = 0; j <= 2; j++) {
      ctx.beginPath();
      ctx.moveTo(0, j * 512);
      ctx.lineTo(s, j * 512);
      ctx.stroke();
    }
  }
  cracks(ctx, s, s, r, 8, "rgba(10,10,10,0.55)", 1.4);
  grain(ctx, s, s, 22, r);
  const litCount = 2;
  const lit = new Set<number>();
  while (lit.size < litCount) lit.add((r() * 8) | 0);
  for (let row = 0; row < 2; row++) {
    for (let col = 0; col < 4; col++) {
      const idx = row * 4 + col;
      const wx = col * 256 + 68;
      const wy = row * 512 + 120;
      let mode = "normal";
      const roll = r();
      if (lit.has(idx)) mode = "lit";
      else if (roll < 0.2) mode = "broken";
      else if (roll < 0.38) mode = "boards";
      else if (roll < 0.55) mode = "curtain";
      // soot streak under window
      const g = ctx.createLinearGradient(0, wy + 200, 0, wy + 330);
      g.addColorStop(0, "rgba(10,10,10,0.35)");
      g.addColorStop(1, "rgba(10,10,10,0)");
      ctx.fillStyle = g;
      ctx.fillRect(wx - 6, wy + 200, 132, 130);
      drawWindow(ctx, wx, wy, 120, 210, mode, r);
      drawWindow(ectx, wx, wy, 120, 210, mode, r, true);
    }
  }
  return { map: toTex(c), emissive: toTex(ce) };
}

function woodTex() {
  const s = 512;
  const r = rng(41);
  const [c, ctx] = mk(s);
  const planks = 4;
  const ph = s / planks;
  for (let p = 0; p < planks; p++) {
    const l = 26 + r() * 10;
    ctx.fillStyle = `hsl(${26 + r() * 6},${34 + r() * 14}%,${l}%)`;
    ctx.fillRect(0, p * ph, s, ph);
    for (let i = 0; i < 40; i++) {
      ctx.strokeStyle = `rgba(20,10,0,${0.1 + r() * 0.25})`;
      ctx.lineWidth = 1 + r() * 1.5;
      const y = p * ph + r() * ph;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.bezierCurveTo(s * 0.3, y + (r() - 0.5) * 6, s * 0.6, y + (r() - 0.5) * 6, s, y + (r() - 0.5) * 4);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(10,5,0,0.7)";
    ctx.fillRect(0, p * ph, s, 3);
    ctx.fillStyle = "#2a2a2a";
    ctx.beginPath();
    ctx.arc(14, p * ph + ph / 2, 3, 0, 7);
    ctx.arc(s - 14, p * ph + ph / 2, 3, 0, 7);
    ctx.fill();
  }
  grain(ctx, s, s, 26, r);
  return toTex(c);
}

function crateTex() {
  const s = 256;
  const r = rng(43);
  const [c, ctx] = mk(s);
  ctx.fillStyle = "#6d4c2a";
  ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 80; i++) {
    ctx.strokeStyle = `rgba(30,15,0,${0.1 + r() * 0.2})`;
    ctx.beginPath();
    const y = r() * s;
    ctx.moveTo(0, y);
    ctx.lineTo(s, y + (r() - 0.5) * 8);
    ctx.stroke();
  }
  ctx.strokeStyle = "#3b2812";
  ctx.lineWidth = 22;
  ctx.strokeRect(11, 11, s - 22, s - 22);
  ctx.fillStyle = "#4d3519";
  ctx.fillRect(0, 0, s, 24);
  ctx.fillRect(0, s - 24, s, 24);
  ctx.fillRect(0, 0, 24, s);
  ctx.fillRect(s - 24, 0, 24, s);
  ctx.save();
  ctx.translate(s / 2, s / 2);
  ctx.rotate(Math.atan2(s, s));
  ctx.fillStyle = "#4d3519";
  ctx.fillRect(-s * 0.7, -11, s * 1.4, 22);
  ctx.rotate(-Math.PI / 2);
  ctx.fillRect(-s * 0.7, -11, s * 1.4, 22);
  ctx.restore();
  ctx.fillStyle = "#222";
  for (const [x, y] of [[12, 12], [s - 12, 12], [12, s - 12], [s - 12, s - 12]]) {
    ctx.beginPath();
    ctx.arc(x, y, 3.5, 0, 7);
    ctx.fill();
  }
  grain(ctx, s, s, 30, r);
  return toTex(c);
}

function paintTex(color: string, seed: number, rust = 0.6) {
  const s = 256;
  const r = rng(seed);
  const [c, ctx] = mk(s);
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, s, s);
  const g = ctx.createLinearGradient(0, 0, 0, s);
  g.addColorStop(0, "rgba(255,255,255,0.12)");
  g.addColorStop(0.5, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,0.35)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, s, s);
  soft(ctx, s, s, r, Math.floor(30 * rust) + 6, ["120,58,22", "90,40,18", "60,30,14", "30,25,20"], 8, 40, 0.5);
  for (let i = 0; i < 40; i++) {
    ctx.strokeStyle = `rgba(${r() > 0.5 ? "230,230,230" : "20,20,20"},0.18)`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    const x = r() * s;
    const y = r() * s;
    ctx.moveTo(x, y);
    ctx.lineTo(x + (r() - 0.5) * 50, y + (r() - 0.5) * 20);
    ctx.stroke();
  }
  grain(ctx, s, s, 28, r);
  return toTex(c);
}

function barrelTex(color: string, explosive: boolean, seed: number) {
  const s = 256;
  const r = rng(seed);
  const [c, ctx] = mk(s);
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, s, s);
  soft(ctx, s, s, r, 20, ["110,50,20", "50,25,10", "20,20,20"], 10, 40, 0.45);
  for (const y of [0.06, 0.5, 0.94]) {
    ctx.fillStyle = "rgba(0,0,0,0.38)";
    ctx.fillRect(0, y * s - 4, s, 8);
    ctx.fillStyle = "rgba(255,255,255,0.12)";
    ctx.fillRect(0, y * s - 6, s, 2);
  }
  if (explosive) {
    for (const u of [0.25, 0.75]) {
      const cx = u * s;
      const cy = s * 0.5;
      ctx.fillStyle = "#e8c21a";
      ctx.beginPath();
      ctx.moveTo(cx, cy - 46);
      ctx.lineTo(cx + 42, cy + 30);
      ctx.lineTo(cx - 42, cy + 30);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#1a1a1a";
      ctx.beginPath();
      ctx.moveTo(cx, cy - 32);
      ctx.lineTo(cx + 29, cy + 22);
      ctx.lineTo(cx - 29, cy + 22);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#ff7a1a";
      ctx.beginPath();
      ctx.moveTo(cx, cy - 18);
      ctx.quadraticCurveTo(cx + 18, cy + 4, cx + 6, cy + 16);
      ctx.quadraticCurveTo(cx, cy + 6, cx - 6, cy + 16);
      ctx.quadraticCurveTo(cx - 16, cy + 2, cx, cy - 18);
      ctx.fill();
    }
  }
  grain(ctx, s, s, 30, r);
  return toTex(c);
}

function skinTex(seed: number, base: string) {
  const s = 256;
  const r = rng(seed);
  const [c, ctx] = mk(s);
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, s, s);
  soft(ctx, s, s, r, 24, ["100,70,100", "60,80,50", "40,50,40", "130,140,100"], 14, 50, 0.4);
  ctx.strokeStyle = "rgba(40,60,60,0.5)";
  ctx.lineWidth = 1.2;
  for (let i = 0; i < 22; i++) {
    ctx.beginPath();
    let x = r() * s;
    let y = r() * s;
    ctx.moveTo(x, y);
    for (let k = 0; k < 6; k++) {
      x += (r() - 0.5) * 30;
      y += (r() - 0.3) * 30;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  soft(ctx, s, s, r, 9, ["110,8,8", "70,5,5"], 6, 22, 0.75);
  grain(ctx, s, s, 36, r);
  return toTex(c);
}

function faceTex(seed: number, base: string, eye: string) {
  const s = 256;
  const r = rng(seed);
  const [c, ctx] = mk(s);
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, s, s);
  soft(ctx, s, s, r, 18, ["100,70,100", "60,80,50", "40,50,40"], 14, 44, 0.4, false);
  // sockets
  ctx.fillStyle = "#0a0505";
  ctx.beginPath();
  ctx.ellipse(86, 100, 30, 24, -0.1, 0, 7);
  ctx.ellipse(170, 100, 30, 24, 0.1, 0, 7);
  ctx.fill();
  // glow eyes
  const eg = (x: number, y: number) => {
    const g = ctx.createRadialGradient(x, y, 0, x, y, 20);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(0.25, eye);
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x - 24, y - 24, 48, 48);
  };
  eg(88, 102);
  eg(168, 102);
  // nose
  ctx.fillStyle = "#1b0e0e";
  ctx.beginPath();
  ctx.ellipse(122, 148, 5, 8, 0, 0, 7);
  ctx.ellipse(136, 148, 5, 8, 0, 0, 7);
  ctx.fill();
  // mouth
  ctx.fillStyle = "#1c0505";
  ctx.beginPath();
  ctx.moveTo(74, 188);
  ctx.quadraticCurveTo(128, 220, 184, 186);
  ctx.quadraticCurveTo(130, 250, 74, 188);
  ctx.fill();
  ctx.fillStyle = "#cfc9a8";
  for (let i = 0; i < 6; i++) ctx.fillRect(86 + i * 15, 194 + Math.sin(i * 0.6) * 6, 7, 9);
  // blood
  ctx.fillStyle = "rgba(110,5,5,0.85)";
  ctx.fillRect(100, 205, 8, 40);
  ctx.fillRect(150, 200, 6, 50);
  soft(ctx, s, s, r, 6, ["120,8,8"], 10, 26, 0.6, false);
  grain(ctx, s, s, 32, r);
  return toTex(c, { repeat: false });
}

function clothTex(seed: number, plaid: boolean) {
  const s = 128;
  const r = rng(seed);
  const [c, ctx] = mk(s);
  ctx.fillStyle = "#cfcfcf";
  ctx.fillRect(0, 0, s, s);
  if (plaid) {
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    for (let i = 0; i < s; i += 32) {
      ctx.fillRect(i, 0, 10, s);
      ctx.fillRect(0, i, s, 10);
    }
  }
  ctx.strokeStyle = "rgba(0,0,0,0.12)";
  for (let i = 0; i < s; i += 3) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, s);
    ctx.stroke();
  }
  soft(ctx, s, s, r, 8, ["40,30,25", "70,10,10", "30,30,30"], 8, 26, 0.5);
  soft(ctx, s, s, r, 4, ["120,5,5"], 5, 14, 0.8);
  ctx.fillStyle = "rgba(10,5,5,0.85)";
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.ellipse(r() * s, r() * s, 3 + r() * 5, 2 + r() * 4, r() * 3, 0, 7);
    ctx.fill();
  }
  grain(ctx, s, s, 40, r);
  return toTex(c);
}

function barkTex() {
  const w = 128;
  const h = 256;
  const r = rng(77);
  const [c, ctx] = mk(w, h);
  ctx.fillStyle = "#3a2e22";
  ctx.fillRect(0, 0, w, h);
  for (let i = 0; i < 70; i++) {
    const x = r() * w;
    ctx.fillStyle = `rgba(${r() > 0.5 ? "15,10,6" : "90,75,58"},${0.2 + r() * 0.3})`;
    ctx.fillRect(x, 0, 1 + r() * 4, h);
  }
  grain(ctx, w, h, 30, r);
  return toTex(c);
}

function doorTex() {
  const w = 256;
  const h = 512;
  const r = rng(91);
  const [c, ctx] = mk(w, h);
  ctx.fillStyle = "#2c2118";
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "#3a2c1f";
  ctx.fillRect(16, 16, w - 32, h - 32);
  ctx.fillStyle = "#1b140e";
  ctx.fillRect(w / 2 - 2, 16, 4, h - 32);
  // planks
  for (let i = 0; i < 4; i++) {
    ctx.save();
    ctx.translate(w / 2, 110 + i * 100);
    ctx.rotate((r() - 0.5) * 0.3);
    ctx.fillStyle = `hsl(30,${28 + r() * 14}%,${24 + r() * 12}%)`;
    ctx.fillRect(-w * 0.7, -20, w * 1.4, 40);
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fillRect(-w * 0.7, 18, w * 1.4, 3);
    ctx.fillStyle = "#222";
    ctx.fillRect(-w / 2 + 14, -3, 6, 6);
    ctx.fillRect(w / 2 - 20, -3, 6, 6);
    ctx.restore();
  }
  // handprint blood
  soft(ctx, w, h, r, 3, ["110,5,5"], 10, 30, 0.7, false);
  ctx.fillStyle = "rgba(100,5,5,0.8)";
  ctx.fillRect(170, 220, 8, 90);
  grain(ctx, w, h, 28, r);
  return toTex(c, { repeat: false });
}

function busTex() {
  const w = 1024;
  const h = 256;
  const r = rng(61);
  const [c, ctx] = mk(w, h);
  ctx.fillStyle = "#b28f16";
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "#1c1c1c";
  ctx.fillRect(0, h * 0.62, w, 12);
  ctx.fillRect(0, h * 0.9, w, 10);
  for (let i = 0; i < 9; i++) {
    const x = 50 + i * 106;
    ctx.fillStyle = "#171b1e";
    ctx.fillRect(x, 40, 86, 85);
    const g = ctx.createLinearGradient(x, 40, x + 86, 125);
    g.addColorStop(0, "rgba(120,150,170,0.25)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x, 40, 86, 85);
    if (r() > 0.6) {
      ctx.fillStyle = "#000";
      ctx.fillRect(x + 20, 40, 50, 60);
    }
  }
  ctx.fillStyle = "#101010";
  ctx.fillRect(w - 90, 40, 60, h * 0.5);
  soft(ctx, w, h, r, 40, ["110,50,20", "50,25,10", "20,20,20"], 14, 60, 0.5, false);
  soft(ctx, w, h, r, 8, ["120,6,6"], 10, 40, 0.5, false);
  grain(ctx, w, h, 30, r);
  return toTex(c, { repeat: false });
}

function glowTex() {
  const s = 128;
  const [c, ctx] = mk(s);
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.25, "rgba(255,255,255,0.55)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, s, s);
  return toTex(c, { repeat: false });
}

function smokeTex() {
  const s = 128;
  const r = rng(3);
  const [c, ctx] = mk(s);
  soft(ctx, s, s, r, 14, ["255,255,255"], 18, 40, 0.35, false);
  // mask edge
  ctx.globalCompositeOperation = "destination-in";
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.7, "rgba(255,255,255,0.6)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, s, s);
  return toTex(c, { repeat: false });
}

function muzzleTex() {
  const s = 128;
  const [c, ctx] = mk(s);
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  g.addColorStop(0, "rgba(255,255,230,1)");
  g.addColorStop(0.2, "rgba(255,210,110,0.9)");
  g.addColorStop(0.6, "rgba(255,120,30,0.25)");
  g.addColorStop(1, "rgba(255,80,0,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, s, s);
  ctx.translate(s / 2, s / 2);
  ctx.fillStyle = "rgba(255,230,160,0.9)";
  for (let i = 0; i < 6; i++) {
    ctx.rotate((Math.PI * 2) / 6);
    ctx.beginPath();
    ctx.moveTo(0, -4);
    ctx.lineTo(s * 0.48, 0);
    ctx.lineTo(0, 4);
    ctx.fill();
  }
  return toTex(c, { repeat: false });
}

function medTex() {
  const s = 128;
  const r = rng(9);
  const [c, ctx] = mk(s);
  ctx.fillStyle = "#e8e8e4";
  ctx.fillRect(0, 0, s, s);
  ctx.fillStyle = "#c91818";
  ctx.fillRect(s / 2 - 12, 24, 24, s - 48);
  ctx.fillRect(24, s / 2 - 12, s - 48, 24);
  ctx.strokeStyle = "#999";
  ctx.lineWidth = 4;
  ctx.strokeRect(2, 2, s - 4, s - 4);
  grain(ctx, s, s, 18, r);
  return toTex(c, { repeat: false });
}

function ammoTex() {
  const s = 128;
  const r = rng(19);
  const [c, ctx] = mk(s);
  ctx.fillStyle = "#4a5a2a";
  ctx.fillRect(0, 0, s, s);
  ctx.fillStyle = "#e8c93a";
  ctx.font = "bold 30px Arial";
  ctx.textAlign = "center";
  ctx.fillText("AMMO", s / 2, 54);
  for (let i = 0; i < 5; i++) {
    ctx.fillStyle = "#d9a520";
    ctx.fillRect(18 + i * 20, 70, 12, 36);
    ctx.fillStyle = "#8a5a18";
    ctx.beginPath();
    ctx.arc(24 + i * 20, 70, 6, Math.PI, 0);
    ctx.fill();
  }
  ctx.strokeStyle = "#2a3414";
  ctx.lineWidth = 5;
  ctx.strokeRect(2, 2, s - 4, s - 4);
  grain(ctx, s, s, 24, r);
  return toTex(c, { repeat: false });
}

function bloodTex(seed: number) {
  const s = 128;
  const r = rng(seed);
  const [c, ctx] = mk(s);
  for (let i = 0; i < 26; i++) {
    const a = r() * Math.PI * 2;
    const d = r() * 40;
    const x = s / 2 + Math.cos(a) * d;
    const y = s / 2 + Math.sin(a) * d;
    const rad = 4 + r() * (26 - d * 0.4);
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    g.addColorStop(0, "rgba(90,4,4,0.95)");
    g.addColorStop(0.7, "rgba(70,3,3,0.8)");
    g.addColorStop(1, "rgba(60,2,2,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
  for (let i = 0; i < 18; i++) {
    const a = r() * Math.PI * 2;
    ctx.fillStyle = "rgba(75,3,3,0.9)";
    ctx.beginPath();
    ctx.arc(s / 2 + Math.cos(a) * (40 + r() * 20), s / 2 + Math.sin(a) * (40 + r() * 20), 1 + r() * 3, 0, 7);
    ctx.fill();
  }
  return toTex(c, { repeat: false });
}

function scorchTex() {
  const s = 128;
  const r = rng(13);
  const [c, ctx] = mk(s);
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  g.addColorStop(0, "rgba(5,5,5,0.95)");
  g.addColorStop(0.6, "rgba(10,10,10,0.7)");
  g.addColorStop(1, "rgba(10,10,10,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, s, s);
  soft(ctx, s, s, r, 12, ["0,0,0"], 8, 24, 0.5, false);
  return toTex(c, { repeat: false });
}

function metalTex() {
  const s = 128;
  const r = rng(55);
  const [c, ctx] = mk(s);
  ctx.fillStyle = "#34373b";
  ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 90; i++) {
    ctx.strokeStyle = `rgba(${r() > 0.5 ? "200,200,210" : "0,0,0"},${0.05 + r() * 0.12})`;
    ctx.beginPath();
    const y = r() * s;
    ctx.moveTo(0, y);
    ctx.lineTo(s, y + (r() - 0.5) * 3);
    ctx.stroke();
  }
  grain(ctx, s, s, 22, r);
  return toTex(c);
}

export type Textures = ReturnType<typeof createTextures>;

export function createTextures() {
  const facades = [
    facade("brick", 101, "#000", 8),
    facade("brick", 102, "#000", 18),
    facade("plaster", 103, "#8a8570"),
    facade("plaster", 104, "#6e7a72"),
    facade("concrete", 105, "#6a6c6a"),
    facade("brick", 106, "#000", 0),
  ];
  return {
    ground: groundTex(),
    asphalt: asphaltTex(),
    roadLine: roadLineTex(),
    concrete: concreteTex(),
    facades,
    wood: woodTex(),
    crate: crateTex(),
    paints: [
      paintTex("#7a1f1f", 201),
      paintTex("#233a5c", 202),
      paintTex("#5a5d5f", 203),
      paintTex("#c9c6bb", 204),
      paintTex("#2e4a31", 205),
      paintTex("#a8791c", 206),
    ],
    barrelRed: barrelTex("#9b1d14", true, 301),
    barrelBlue: barrelTex("#274b78", false, 302),
    barrelGrey: barrelTex("#575a55", false, 303),
    skins: [
      skinTex(401, "#7a8a68"),
      skinTex(402, "#8a8e74"),
      skinTex(403, "#6a7a64"),
    ],
    faceYellow: faceTex(411, "#7a8a68", "#f2ff7a"),
    faceRed: faceTex(412, "#86806a", "#ff3b2b"),
    cloth: [clothTex(421, false), clothTex(422, true)],
    bark: barkTex(),
    door: doorTex(),
    bus: busTex(),
    glow: glowTex(),
    smoke: smokeTex(),
    muzzle: muzzleTex(),
    med: medTex(),
    ammo: ammoTex(),
    blood: [bloodTex(501), bloodTex(502), bloodTex(503)],
    scorch: scorchTex(),
    metal: metalTex(),
  };
}
