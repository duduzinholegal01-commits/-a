import * as THREE from "three";
import { createTextures, rng } from "./textures";
import type { Textures } from "./textures";
import { AudioEngine } from "./audio";
import { buildWorld, HALF } from "./world";
import type { World, Collider, BarrelObj } from "./world";
import { createZombie, buildGun, buildCrowbar, createPickup } from "./models";
import type { ZType, ZRig, GunModel, GunKind, PickupKind } from "./models";

/* ------------------------------------------------------------------ */
/* Public types                                                         */
/* ------------------------------------------------------------------ */

export interface WeaponHud {
  name: string;
  owned: boolean;
  mag: number;
  reserve: number;
  magSize: number;
}

export interface HudState {
  hp: number;
  stamina: number;
  weapons: WeaponHud[];
  cur: number;
  reloading: boolean;
  reloadProg: number;
  flashlight: boolean;
  wave: number;
  kills: number;
  score: number;
  remaining: number;
  breakTime: number | null;
  spread: number;
  sprinting: boolean;
}

export interface GameStats {
  score: number;
  kills: number;
  wave: number;
  headshots: number;
  shots: number;
  hits: number;
  time: number;
}

export interface GameEvents {
  onHud(h: HudState): void;
  onMessage(text: string, kind: "info" | "good" | "bad"): void;
  onHurt(angle: number, dmg: number): void;
  onHit(head: boolean, kill: boolean, points: number): void;
  onWave(n: number, title: string, sub: string): void;
  onDead(s: GameStats): void;
  onPause(): void;
}

type GameState = "menu" | "playing" | "paused" | "dead";

interface WeaponDef {
  id: GunKind;
  name: string;
  dmg: number;
  pellets: number;
  rate: number;
  auto: boolean;
  mag: number;
  reload: number;
  spread: number;
  recoil: number;
  maxReserve: number;
  pack: number;
}

const WEAPONS: WeaponDef[] = [
  { id: "pistol", name: "PISTOLA M9", dmg: 32, pellets: 1, rate: 0.2, auto: false, mag: 12, reload: 1.25, spread: 0.004, recoil: 1.0, maxReserve: 120, pack: 24 },
  { id: "shotgun", name: "ESPINGARDA", dmg: 17, pellets: 9, rate: 0.9, auto: false, mag: 6, reload: 2.3, spread: 0.05, recoil: 3.4, maxReserve: 36, pack: 8 },
  { id: "rifle", name: "RIFLE DE ASSALTO", dmg: 26, pellets: 1, rate: 0.092, auto: true, mag: 30, reload: 2.1, spread: 0.009, recoil: 1.15, maxReserve: 180, pack: 45 },
];

const VM_BASE: [number, number, number][] = [
  [0.17, -0.2, -0.46],
  [0.19, -0.21, -0.5],
  [0.18, -0.22, -0.46],
];

interface ZStats {
  hp: number;
  speed: number;
  speedVar: number;
  dmg: number;
  radius: number;
  score: number;
  reach: number;
}
const ZSTATS: Record<ZType, ZStats> = {
  walker: { hp: 70, speed: 1.4, speedVar: 0.9, dmg: 10, radius: 0.38, score: 100, reach: 1.5 },
  runner: { hp: 45, speed: 3.7, speedVar: 1.1, dmg: 8, radius: 0.34, score: 150, reach: 1.45 },
  brute: { hp: 420, speed: 2.1, speedVar: 0.3, dmg: 32, radius: 0.7, score: 500, reach: 2.1 },
};

interface Zombie {
  id: number;
  type: ZType;
  rig: ZRig;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  speed: number;
  dmg: number;
  radius: number;
  reach: number;
  state: "idle" | "chase" | "dying";
  phase: number;
  attacking: boolean;
  attackT: number;
  attackCd: number;
  hitDone: boolean;
  groanT: number;
  stagger: number;
  deathT: number;
  flash: number;
  side: number;
  score: number;
  wobble: number;
}

interface Pickup {
  kind: PickupKind;
  root: THREE.Group;
  float: THREE.Group;
  x: number;
  z: number;
  t: number;
}

interface BoxP {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  max: number;
  grav: number;
  size: number;
  active: boolean;
}

interface SpriteP {
  sprite: THREE.Sprite;
  vel: THREE.Vector3;
  life: number;
  max: number;
  s0: number;
  s1: number;
  op: number;
  rise: number;
  drag: number;
  c0: THREE.Color;
  c1: THREE.Color;
  active: boolean;
}

interface Decal {
  mesh: THREE.Mesh;
  life: number;
  max: number;
}

const V3 = THREE.Vector3;
const Z_AXIS = new V3(0, 0, 1);
const EYE = 1.7;

function rayBox(o: THREE.Vector3, d: THREE.Vector3, c: Collider, maxT: number): number | null {
  let tmin = 0;
  let tmax = maxT;
  const axes: [number, number, number, number][] = [
    [o.x, d.x, c.minX, c.maxX],
    [o.y, d.y, 0, c.h],
    [o.z, d.z, c.minZ, c.maxZ],
  ];
  for (const [oo, dd, lo, hi] of axes) {
    if (Math.abs(dd) < 1e-8) {
      if (oo < lo || oo > hi) return null;
    } else {
      let t1 = (lo - oo) / dd;
      let t2 = (hi - oo) / dd;
      if (t1 > t2) {
        const tmp = t1;
        t1 = t2;
        t2 = tmp;
      }
      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return null;
    }
  }
  return tmin;
}

function wrapAngle(a: number) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

/* ------------------------------------------------------------------ */

export class Game {
  private container: HTMLElement;
  private radar: HTMLCanvasElement;
  private radarCtx: CanvasRenderingContext2D;
  private ev: GameEvents;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private T: Textures;
  private world: World;
  private audio: AudioEngine | null = null;
  private rnd = rng(Math.floor(Math.random() * 1e9));

  private state: GameState = "menu";
  private raf = 0;
  private last = performance.now();
  private disposed = false;
  private lockFailed = false;
  private sens = 1;
  private volume = 0.7;

  // lights
  private hemi: THREE.HemisphereLight;
  private moon: THREE.DirectionalLight;
  private flash: THREE.SpotLight;
  private muzzleLight: THREE.PointLight;
  private boomLight: THREE.PointLight;
  private boomT = 0;
  private skyGroup = new THREE.Group();
  private skyMat: THREE.ShaderMaterial;
  private lightningT = 0;
  private nextLightning = 8;
  private lightningPulse = 0;

  // player
  private pos = new V3(0, 0, 4);
  private vel = new V3();
  private yaw = 0;
  private pitch = 0;
  private hp = 100;
  private godMode = false;
  private infiniteAmmo = false;
  private infiniteStamina = false;
  private speedMul = 1;
  private freezeZombies = false;
  private rainEnabled = true;
  private stamina = 100;
  private exhausted = false;
  private staminaDelay = 0;
  private onGround = true;
  private bobPhase = 0;
  private stepAcc = 0;
  private shake = 0;
  private flashOn = true;
  private fov = 75;
  private heartT = 0;
  private sprintB = 0;
  private deathT = 0;
  private deadReported = false;

  // weapons
  private cur = 0;
  private owned = [true, false, false];
  private mags = [12, 0, 0];
  private reserves = [48, 0, 0];
  private cooldown = 0;
  private reloading = false;
  private reloadT = 0;
  private switchT = 0;
  private fireHeld = false;
  private fireBuf = 0;
  private recoilV = 0;
  private flashT = 0;
  private pumpT = 0;
  private swayX = 0;
  private swayY = 0;
  private melee = { active: false, t: 0, hit: false, cd: 0 };

  // view-models
  private vm = new THREE.Group();
  private guns: GunModel[] = [];
  private flashSprites: THREE.Sprite[] = [];
  private crowbar: THREE.Group;

  // entities
  private zombies: Zombie[] = [];
  private zid = 1;
  private pickups: Pickup[] = [];
  private pendingBlasts: { b: BarrelObj; t: number }[] = [];
  private scorches: THREE.Mesh[] = [];

  // particles
  private boxPool: BoxP[] = [];
  private smokePool: SpriteP[] = [];
  private firePool: SpriteP[] = [];
  private decals: Decal[] = [];
  private decalIdx = 0;
  private tracers: { mesh: THREE.Mesh; life: number }[] = [];
  private rain!: THREE.LineSegments;
  private rainPos!: Float32Array;
  private rainBase!: Float32Array;
  private boxMats: Record<string, THREE.MeshBasicMaterial> = {};

  // game flow
  private wave = 0;
  private waveState: "break" | "active" = "break";
  private breakT = 6;
  private toSpawn: ZType[] = [];
  private spawnT = 0;
  private kills = 0;
  private score = 0;
  private headshots = 0;
  private shots = 0;
  private hits = 0;
  private time = 0;

  private keys: Record<string, boolean> = {};
  private hudAcc = 0;
  private radarAcc = 0;
  private menuT = 0;
  private raycaster = new THREE.Raycaster();
  private tmpV = new V3();
  private tmpV2 = new V3();
  private contactN = { x: 0, z: 0 };

  constructor(container: HTMLElement, radar: HTMLCanvasElement, events: GameEvents) {
    this.container = container;
    this.radar = radar;
    this.radarCtx = radar.getContext("2d")!;
    this.ev = events;

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.domElement.style.display = "block";
    container.appendChild(this.renderer.domElement);

    this.scene.fog = new THREE.FogExp2(0x0e1626, 0.017);
    this.camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 700);
    this.camera.rotation.order = "YXZ";
    this.scene.add(this.camera);

    this.T = createTextures();

    /* ---- lights ---- */
    this.hemi = new THREE.HemisphereLight(0x6677aa, 0x2c2c28, 1.0);
    this.scene.add(this.hemi);
    this.moon = new THREE.DirectionalLight(0x9db4ff, 1.5);
    this.moon.castShadow = true;
    this.moon.shadow.mapSize.set(2048, 2048);
    const sc = this.moon.shadow.camera;
    sc.left = -45;
    sc.right = 45;
    sc.top = 45;
    sc.bottom = -45;
    sc.near = 1;
    sc.far = 160;
    sc.updateProjectionMatrix();
    this.moon.shadow.bias = -0.0004;
    this.moon.shadow.normalBias = 0.05;
    this.scene.add(this.moon, this.moon.target);

    this.flash = new THREE.SpotLight(0xfff1d6, 480, 60, 0.43, 0.55, 2);
    this.flash.position.set(0.22, -0.15, 0.1);
    this.flash.target.position.set(0, 0, -10);
    this.camera.add(this.flash, this.flash.target);
    this.muzzleLight = new THREE.PointLight(0xffb060, 0, 16, 2);
    this.muzzleLight.position.set(0.2, -0.05, -1.0);
    this.camera.add(this.muzzleLight);
    this.boomLight = new THREE.PointLight(0xff8830, 0, 45, 2);
    this.scene.add(this.boomLight);

    /* ---- sky ---- */
    this.skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: { flash: { value: 0 } },
      vertexShader: `varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `varying vec3 vP; uniform float flash;
        void main(){
          float h = normalize(vP).y;
          vec3 bottom = vec3(0.07,0.10,0.17);
          vec3 mid = vec3(0.08,0.11,0.20);
          vec3 top = vec3(0.015,0.025,0.06);
          vec3 c = mix(bottom, mid, smoothstep(-0.02,0.2,h));
          c = mix(c, top, smoothstep(0.15,0.85,h));
          c += flash * vec3(0.55,0.6,0.8) * (0.35 + 0.65*smoothstep(0.0,0.8,h));
          gl_FragColor = vec4(c,1.0);
        }`,
    });
    const dome = new THREE.Mesh(new THREE.SphereGeometry(450, 24, 16), this.skyMat);
    dome.renderOrder = -10;
    this.skyGroup.add(dome);
    const starGeo = new THREE.BufferGeometry();
    const sp = new Float32Array(900 * 3);
    for (let i = 0; i < 900; i++) {
      const u = Math.random() * Math.PI * 2;
      const y = 0.05 + Math.random() * 0.95;
      const rr = Math.sqrt(1 - y * y);
      sp[i * 3] = Math.cos(u) * rr * 430;
      sp[i * 3 + 1] = y * 430;
      sp[i * 3 + 2] = Math.sin(u) * rr * 430;
    }
    starGeo.setAttribute("position", new THREE.BufferAttribute(sp, 3));
    const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xcfd8ff, size: 1.7, sizeAttenuation: false, fog: false, transparent: true, opacity: 0.8, depthWrite: false }));
    stars.renderOrder = -9;
    this.skyGroup.add(stars);
    const moonDir = new V3(-30, 50, -25).normalize().multiplyScalar(420);
    const moonGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.T.glow, color: 0x8fa8e8, fog: false, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.7 }));
    moonGlow.scale.setScalar(160);
    moonGlow.position.copy(moonDir);
    const moonDisc = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.T.glow, color: 0xf2f6ff, fog: false, transparent: true, depthWrite: false }));
    moonDisc.scale.setScalar(36);
    moonDisc.position.copy(moonDir);
    this.skyGroup.add(moonGlow, moonDisc);
    this.scene.add(this.skyGroup);

    /* ---- world ---- */
    this.world = buildWorld(this.scene, this.T);

    /* ---- view-models ---- */
    this.camera.add(this.vm);
    (["pistol", "shotgun", "rifle"] as GunKind[]).forEach((k, i) => {
      const gm = buildGun(k, this.T);
      gm.group.position.set(...VM_BASE[i]);
      gm.group.visible = i === 0;
      const fs = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.T.muzzle, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false, opacity: 0 }));
      fs.position.copy(gm.muzzle);
      fs.scale.setScalar(k === "shotgun" ? 0.6 : 0.4);
      gm.group.add(fs);
      this.flashSprites.push(fs);
      this.vm.add(gm.group);
      this.guns.push(gm);
    });
    this.crowbar = buildCrowbar(this.T);
    this.crowbar.visible = false;
    this.vm.add(this.crowbar);

    /* ---- particle pools ---- */
    const unit = new THREE.BoxGeometry(1, 1, 1);
    this.boxMats = {
      blood: new THREE.MeshBasicMaterial({ color: 0x7a0606, fog: true }),
      spark: new THREE.MeshBasicMaterial({ color: 0xffc860, fog: false }),
      debris: new THREE.MeshBasicMaterial({ color: 0x1a1a1a }),
      ember: new THREE.MeshBasicMaterial({ color: 0xff7a20, fog: false }),
    };
    for (let i = 0; i < 280; i++) {
      const m = new THREE.Mesh(unit, this.boxMats.blood);
      m.visible = false;
      this.scene.add(m);
      this.boxPool.push({ mesh: m, vel: new V3(), life: 0, max: 1, grav: -14, size: 0.05, active: false });
    }
    const mkSprites = (n: number, additive: boolean, pool: SpriteP[]) => {
      for (let i = 0; i < n; i++) {
        const s = new THREE.Sprite(
          new THREE.SpriteMaterial({
            map: additive ? this.T.glow : this.T.smoke,
            transparent: true,
            depthWrite: false,
            blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
            opacity: 0,
          })
        );
        s.visible = false;
        this.scene.add(s);
        pool.push({ sprite: s, vel: new V3(), life: 0, max: 1, s0: 1, s1: 1, op: 1, rise: 0, drag: 1, c0: new THREE.Color(), c1: new THREE.Color(), active: false });
      }
    };
    mkSprites(110, false, this.smokePool);
    mkSprites(130, true, this.firePool);

    const decalGeo = new THREE.PlaneGeometry(1, 1);
    for (let i = 0; i < 70; i++) {
      const mat = new THREE.MeshBasicMaterial({
        map: this.T.blood[i % 3],
        transparent: true,
        depthWrite: false,
        opacity: 0,
        color: 0xb8b8b8,
        polygonOffset: true,
        polygonOffsetFactor: -8,
        polygonOffsetUnits: -8,
      });
      const m = new THREE.Mesh(decalGeo, mat);
      m.rotation.x = -Math.PI / 2;
      m.visible = false;
      this.scene.add(m);
      this.decals.push({ mesh: m, life: 0, max: 1 });
    }
    const tg = new THREE.BoxGeometry(0.014, 0.014, 1);
    for (let i = 0; i < 30; i++) {
      const m = new THREE.Mesh(tg, new THREE.MeshBasicMaterial({ color: 0xffe2a0, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
      m.visible = false;
      this.scene.add(m);
      this.tracers.push({ mesh: m, life: 0 });
    }

    /* ---- rain ---- */
    const N = 1800;
    this.rainBase = new Float32Array(N * 3);
    this.rainPos = new Float32Array(N * 6);
    for (let i = 0; i < N; i++) {
      this.rainBase[i * 3] = (Math.random() - 0.5) * 48;
      this.rainBase[i * 3 + 1] = Math.random() * 26;
      this.rainBase[i * 3 + 2] = (Math.random() - 0.5) * 48;
    }
    const rg = new THREE.BufferGeometry();
    rg.setAttribute("position", new THREE.BufferAttribute(this.rainPos, 3));
    this.rain = new THREE.LineSegments(rg, new THREE.LineBasicMaterial({ color: 0x9fb4d0, transparent: true, opacity: 0.28, depthWrite: false }));
    this.rain.frustumCulled = false;
    this.scene.add(this.rain);

    /* ---- events ---- */
    window.addEventListener("resize", this.onResize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    document.addEventListener("mousemove", this.onMouseMove);
    document.addEventListener("mousedown", this.onMouseDown);
    document.addEventListener("mouseup", this.onMouseUp);
    document.addEventListener("wheel", this.onWheel, { passive: true });
    document.addEventListener("pointerlockchange", this.onLockChange);
    document.addEventListener("pointerlockerror", this.onLockError);
    window.addEventListener("blur", this.onBlur);

    this.setupMenuScene();
    this.loop();
  }

  /* ================================================================ */
  /* Public API                                                         */
  /* ================================================================ */

  setSensitivity(v: number) {
    this.sens = v;
  }

  setVolume(v: number) {
    this.volume = v;
    this.audio?.setVolume(v);
  }

  start() {
    if (!this.audio) {
      try {
        this.audio = new AudioEngine();
      } catch {
        this.audio = null;
      }
    }
    this.audio?.setVolume(this.volume);
    this.audio?.resume();
    this.audio?.startAmbient();
    this.reset();
    this.state = "playing";
    this.requestLock();
    this.ev.onMessage("Sobreviva. Pegue armas e munição pelo mapa.", "info");
  }

  resume() {
    if (this.state !== "paused") return;
    this.state = "playing";
    this.audio?.resume();
    this.last = performance.now();
    this.requestLock();
  }

  pause() {
    if (this.state !== "playing") return;
    this.state = "paused";
    this.fireHeld = false;
    this.keys = {};
    this.audio?.suspend();
    if (document.pointerLockElement) document.exitPointerLock();
    this.ev.onPause();
  }

  toMenu() {
    this.state = "menu";
    this.audio?.resume();
    this.setupMenuScene();
    if (document.pointerLockElement) document.exitPointerLock();
  }

  getState() {
    return this.state;
  }

  // Admin methods
  setGodMode(on: boolean) {
    this.godMode = on;
    if (on) this.hp = Math.max(this.hp, 100);
    this.ev.onMessage(on ? "Modo Deus ATIVADO" : "Modo Deus DESATIVADO", "info");
  }

  setInfiniteAmmo(on: boolean) {
    this.infiniteAmmo = on;
    if (on) {
      for (let i = 0; i < 3; i++) {
        this.owned[i] = true;
        this.mags[i] = WEAPONS[i].mag;
        this.reserves[i] = WEAPONS[i].maxReserve;
      }
    }
    this.ev.onMessage(on ? "Munição Infinita ATIVADA" : "Munição Infinita DESATIVADA", "info");
  }

  adminSetHp(hp: number) {
    this.hp = Math.max(0, Math.min(999, hp));
    this.ev.onMessage(`Vida definida para ${this.hp}`, "good");
  }

  adminSpawnZombie(type: "walker" | "runner" | "brute") {
    const ang = Math.random() * Math.PI * 2;
    const dist = 8 + Math.random() * 6;
    const x = this.pos.x + Math.sin(ang) * dist;
    const z = this.pos.z + Math.cos(ang) * dist;
    this.spawnZombie(type, x, z, false);
    this.ev.onMessage(`Zumbi ${type} spawnado`, "bad");
  }

  adminKillAll() {
    for (const z of this.zombies) {
      if (z.state !== "dying") {
        z.hp = 0;
        z.state = "dying";
      }
    }
    this.ev.onMessage("Todos os zumbis eliminados", "good");
  }

  adminSetWave(n: number) {
    this.wave = Math.max(0, n - 1);
    this.waveState = "break";
    this.breakT = 1;
    this.ev.onMessage(`Próxima onda definida para ${n}`, "info");
  }

  adminGiveAllWeapons() {
    for (let i = 0; i < 3; i++) {
      this.owned[i] = true;
      this.mags[i] = WEAPONS[i].mag;
      this.reserves[i] = WEAPONS[i].maxReserve;
    }
    this.ev.onMessage("Todas as armas e munição máxima dadas", "good");
  }

  setInfiniteStamina(on: boolean) {
    this.infiniteStamina = on;
    if (on) this.stamina = 100;
    this.ev.onMessage(on ? "Stamina Infinita ATIVADA" : "Stamina Infinita DESATIVADA", "info");
  }

  setSpeedMultiplier(mul: number) {
    this.speedMul = Math.max(0.5, Math.min(5, mul));
    this.ev.onMessage(`Velocidade definida para ${this.speedMul}x`, "info");
  }

  setFreezeZombies(on: boolean) {
    this.freezeZombies = on;
    this.ev.onMessage(on ? "Zumbis CONGELADOS" : "Zumbis LIBERADOS", "info");
  }

  toggleRain() {
    this.rainEnabled = !this.rainEnabled;
    if (this.rain) this.rain.visible = this.rainEnabled;
    this.ev.onMessage(this.rainEnabled ? "Chuva ATIVADA" : "Chuva DESATIVADA", "info");
  }

  adminSetScore(score: number) {
    this.score = Math.max(0, score);
    this.ev.onMessage(`Pontos definidos para ${this.score}`, "good");
  }

  adminTeleportHome() {
    this.pos.set(0, 0, 4);
    this.vel.set(0, 0, 0);
    this.ev.onMessage("Teleportado para o centro", "good");
  }

  adminClearPickups() {
    for (const p of this.pickups) {
      this.scene.remove(p.root);
    }
    this.pickups.length = 0;
    this.ev.onMessage("Todos os itens do chão removidos", "info");
  }

  adminAnnounce(text: string) {
    this.ev.onWave(0, "ANÚNCIO", text.toUpperCase());
    this.ev.onMessage(text, "info");
  }

  applySkinCode(code: string): boolean {
    const skins: Record<string, () => void> = {
      "NEON": () => { this.ev.onMessage("Skin NEON aplicada! Armas brilham no escuro.", "good"); },
      "GOLD": () => { this.ev.onMessage("Skin OURO aplicada! Armas douradas.", "good"); },
      "BLOOD": () => { this.ev.onMessage("Skin SANGUE aplicada! Efeito visual ativado.", "good"); },
      "ICE": () => { this.ev.onMessage("Skin GELO aplicada! Zumbis andam mais devagar.", "good"); this.speedMul = 0.8; },
      "SHADOW": () => { this.ev.onMessage("Skin SOMBRA aplicada! Mais difícil de ver.", "good"); },
      "MINECRAFT23": () => { this.ev.onMessage("Código secreto MINECRAFT23! Bônus especial.", "good"); this.score += 5000; },
    };
    const upper = code.trim().toUpperCase();
    if (skins[upper]) {
      skins[upper]();
      return true;
    }
    this.ev.onMessage("Código de skin inválido", "bad");
    return false;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    document.removeEventListener("mousemove", this.onMouseMove);
    document.removeEventListener("mousedown", this.onMouseDown);
    document.removeEventListener("mouseup", this.onMouseUp);
    document.removeEventListener("wheel", this.onWheel);
    document.removeEventListener("pointerlockchange", this.onLockChange);
    document.removeEventListener("pointerlockerror", this.onLockError);
    window.removeEventListener("blur", this.onBlur);
    this.audio?.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) this.container.removeChild(this.renderer.domElement);
    if (document.pointerLockElement) document.exitPointerLock();
  }

  /* ================================================================ */
  /* Input                                                              */
  /* ================================================================ */

  private requestLock() {
    try {
      const p = this.renderer.domElement.requestPointerLock() as unknown as Promise<void> | undefined;
      if (p && typeof p.catch === "function") p.catch(() => (this.lockFailed = true));
    } catch {
      this.lockFailed = true;
    }
  }

  private onLockChange = () => {
    const locked = document.pointerLockElement === this.renderer.domElement;
    if (locked) this.lockFailed = false;
    if (!locked && this.state === "playing" && !this.lockFailed) this.pause();
  };

  private onLockError = () => {
    this.lockFailed = true;
  };

  private onBlur = () => {
    this.keys = {};
    this.fireHeld = false;
    if (this.state === "playing") this.pause();
  };

  private onResize = () => {
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  private onMouseMove = (e: MouseEvent) => {
    if (this.state !== "playing") return;
    const locked = document.pointerLockElement === this.renderer.domElement;
    if (!locked && !this.lockFailed) return;
    const s = 0.0022 * this.sens;
    this.yaw -= e.movementX * s;
    this.pitch -= e.movementY * s;
    this.pitch = Math.max(-1.5, Math.min(1.5, this.pitch));
    this.swayX += -e.movementX * 0.0003;
    this.swayY += -e.movementY * 0.0003;
  };

  private onMouseDown = (e: MouseEvent) => {
    if (this.state !== "playing" || e.button !== 0) return;
    this.fireHeld = true;
    this.fireBuf = 0.14;
    if (!document.pointerLockElement && !this.lockFailed) this.requestLock();
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.fireHeld = false;
  };

  private onWheel = (e: WheelEvent) => {
    if (this.state !== "playing") return;
    const dir = e.deltaY > 0 ? 1 : -1;
    for (let k = 1; k <= 3; k++) {
      const i = (this.cur + dir * k + 30) % 3;
      if (this.owned[i]) {
        this.switchTo(i);
        break;
      }
    }
  };

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    this.keys[e.code] = true;
    if (this.state === "playing") {
      if (e.code === "Digit1") this.switchTo(0);
      else if (e.code === "Digit2") this.switchTo(1);
      else if (e.code === "Digit3") this.switchTo(2);
      else if (e.code === "KeyR") this.startReload();
      else if (e.code === "KeyF") {
        this.flashOn = !this.flashOn;
        this.flash.visible = this.flashOn;
        this.audio?.flashlight();
      } else if (e.code === "KeyV") this.startMelee();
      else if (e.code === "KeyP") this.pause();
      else if (e.code === "Space") e.preventDefault();
    }
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Tab"].includes(e.code)) e.preventDefault();
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  /* ================================================================ */
  /* Setup / reset                                                      */
  /* ================================================================ */

  private clearZombies() {
    for (const z of this.zombies) {
      this.scene.remove(z.rig.group);
      z.rig.mats.forEach((m) => m.dispose());
    }
    this.zombies = [];
  }

  private setupMenuScene() {
    this.clearZombies();
    this.clearPickups();
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + this.rnd() * 0.5;
      const d = 7 + this.rnd() * 9;
      const x = Math.cos(a) * d;
      const zz = Math.sin(a) * d;
      if (this.circleHits(x, zz, 0.6)) continue;
      const z = this.spawnZombie(i % 4 === 0 ? "runner" : "walker", x, zz, true);
      z.yaw = this.rnd() * 6.28;
    }
  }

  private reset() {
    this.clearZombies();
    this.clearPickups();
    for (const p of this.boxPool) {
      p.active = false;
      p.mesh.visible = false;
    }
    for (const p of [...this.smokePool, ...this.firePool]) {
      p.active = false;
      p.sprite.visible = false;
    }
    for (const d of this.decals) d.mesh.visible = false;
    for (const s of this.scorches) this.scene.remove(s);
    this.scorches = [];
    this.pendingBlasts = [];
    for (const b of this.world.barrels) {
      if (b.dead) {
        b.dead = false;
        b.obj.visible = true;
        this.world.colliders.push(b.col);
      }
      b.hp = 40;
    }
    this.pos.set(0, 0, 4);
    this.vel.set(0, 0, 0);
    this.yaw = 0;
    this.pitch = 0;
    this.hp = 100;
    this.stamina = 100;
    this.exhausted = false;
    this.cur = 0;
    this.owned = [true, false, false];
    this.mags = [12, 0, 0];
    this.reserves = [48, 0, 0];
    this.cooldown = 0;
    this.reloading = false;
    this.switchT = 0;
    this.melee = { active: false, t: 0, hit: false, cd: 0 };
    this.guns.forEach((g, i) => (g.group.visible = i === 0));
    this.crowbar.visible = false;
    this.wave = 0;
    this.waveState = "break";
    this.breakT = 6;
    this.toSpawn = [];
    this.kills = 0;
    this.score = 0;
    this.headshots = 0;
    this.shots = 0;
    this.hits = 0;
    this.time = 0;
    this.deathT = 0;
    this.deadReported = false;
    this.shake = 0;
    this.flashOn = true;
    this.flash.visible = true;
    this.lockFailed = false;
    this.camera.rotation.z = 0;

    this.spawnPickup("shotgun", this.world.shotgunPos.x, this.world.shotgunPos.z);
    this.spawnPickup("rifle", this.world.riflePos.x, this.world.riflePos.z);
    this.spawnPickup("ammo", 4, 8);
    this.spawnPickup("health", -5, -7);
    this.spawnPickup("ammo", -12, 8);
    this.spawnPickup("health", 14, -9);
  }

  /* ================================================================ */
  /* Utility                                                            */
  /* ================================================================ */

  private circleHits(x: number, z: number, r: number): boolean {
    for (const c of this.world.colliders) {
      const cx = Math.max(c.minX, Math.min(x, c.maxX));
      const cz = Math.max(c.minZ, Math.min(z, c.maxZ));
      const dx = x - cx;
      const dz = z - cz;
      if (dx * dx + dz * dz < r * r) return true;
    }
    return false;
  }

  /** push circle out of colliders, returns true on contact */
  private resolve(p: { x: number; z: number }, r: number): boolean {
    let hit = false;
    for (const c of this.world.colliders) {
      const cx = Math.max(c.minX, Math.min(p.x, c.maxX));
      const cz = Math.max(c.minZ, Math.min(p.z, c.maxZ));
      let dx = p.x - cx;
      let dz = p.z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 >= r * r) continue;
      hit = true;
      if (d2 > 1e-8) {
        const d = Math.sqrt(d2);
        dx /= d;
        dz /= d;
        p.x += dx * (r - d);
        p.z += dz * (r - d);
        this.contactN.x = dx;
        this.contactN.z = dz;
      } else {
        const l = p.x - c.minX;
        const rr = c.maxX - p.x;
        const t = p.z - c.minZ;
        const b = c.maxZ - p.z;
        const m = Math.min(l, rr, t, b);
        if (m === l) {
          p.x = c.minX - r;
          this.contactN.x = -1;
          this.contactN.z = 0;
        } else if (m === rr) {
          p.x = c.maxX + r;
          this.contactN.x = 1;
          this.contactN.z = 0;
        } else if (m === t) {
          p.z = c.minZ - r;
          this.contactN.x = 0;
          this.contactN.z = -1;
        } else {
          p.z = c.maxZ + r;
          this.contactN.x = 0;
          this.contactN.z = 1;
        }
      }
    }
    const lim = HALF - 0.6;
    if (p.x > lim) p.x = lim;
    if (p.x < -lim) p.x = -lim;
    if (p.z > lim) p.z = lim;
    if (p.z < -lim) p.z = -lim;
    return hit;
  }

  private aliveCount() {
    let n = 0;
    for (const z of this.zombies) if (z.state !== "dying") n++;
    return n;
  }

  private panFor(x: number, z: number) {
    const rx = Math.cos(this.yaw);
    const rz = -Math.sin(this.yaw);
    const dx = x - this.pos.x;
    const dz = z - this.pos.z;
    const d = Math.hypot(dx, dz) || 1;
    return (dx * rx + dz * rz) / d;
  }

  /* ================================================================ */
  /* Zombies                                                            */
  /* ================================================================ */

  private spawnZombie(type: ZType, x: number, z: number, idle = false): Zombie {
    const st = ZSTATS[type];
    const rig = createZombie(type, this.T, this.rnd);
    const hpMul = 1 + this.wave * 0.07;
    const z0: Zombie = {
      id: this.zid++,
      type,
      rig,
      x,
      z,
      yaw: Math.atan2(this.pos.x - x, this.pos.z - z),
      hp: st.hp * hpMul,
      maxHp: st.hp * hpMul,
      speed: (st.speed + this.rnd() * st.speedVar) * (1 + this.wave * 0.012),
      dmg: st.dmg,
      radius: st.radius,
      reach: st.reach,
      state: idle ? "idle" : "chase",
      phase: this.rnd() * 6,
      attacking: false,
      attackT: 0,
      attackCd: 0.3,
      hitDone: false,
      groanT: 1 + this.rnd() * 5,
      stagger: 0,
      deathT: 0,
      flash: 0,
      side: this.rnd() > 0.5 ? 1 : -1,
      score: st.score,
      wobble: this.rnd() * 6,
    };
    rig.group.position.set(x, 0, z);
    rig.group.rotation.y = z0.yaw;
    rig.group.updateMatrixWorld(true);
    this.scene.add(rig.group);
    this.zombies.push(z0);
    return z0;
  }

  private findSpawnPoint(): [number, number] {
    for (let i = 0; i < 25; i++) {
      const a = this.rnd() * Math.PI * 2;
      const d = 30 + this.rnd() * 20;
      let x = this.pos.x + Math.cos(a) * d;
      let z = this.pos.z + Math.sin(a) * d;
      const lim = HALF - 2;
      x = Math.max(-lim, Math.min(lim, x));
      z = Math.max(-lim, Math.min(lim, z));
      if (Math.hypot(x - this.pos.x, z - this.pos.z) < 22) continue;
      if (this.circleHits(x, z, 1.0)) continue;
      return [x, z];
    }
    return [this.pos.x > 0 ? -50 : 50, this.pos.z > 0 ? -50 : 50];
  }

  private randomFreePoint(minFromPlayer: number): [number, number] {
    for (let i = 0; i < 40; i++) {
      const x = (this.rnd() - 0.5) * 2 * (HALF - 5);
      const z = (this.rnd() - 0.5) * 2 * (HALF - 5);
      if (Math.hypot(x - this.pos.x, z - this.pos.z) < minFromPlayer) continue;
      if (this.circleHits(x, z, 1.5)) continue;
      return [x, z];
    }
    return [8, 8];
  }

  private updateZombies(dt: number, active: boolean) {
    const px = this.pos.x;
    const pz = this.pos.z;
    const tmp = { x: 0, z: 0 };
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      const g = z.rig.group;
      const rig = z.rig;
      z.flash = Math.max(0, z.flash - dt * 4);
      const em = z.flash * 0.7;
      for (const m of rig.mats) m.emissive.setRGB(em, em * 0.1, em * 0.1);

      if (z.state === "dying") {
        z.deathT += dt;
        const t = Math.min(1, z.deathT / 0.65);
        const e = 1 - (1 - t) * (1 - t);
        g.rotation.x = -Math.PI / 2 * e;
        g.position.y = 0.1 * e - Math.max(0, z.deathT - 7) * 0.25;
        rig.armL.rotation.x = -1.2 * (1 - e) + 0.4 * e;
        rig.armR.rotation.x = -1.2 * (1 - e) + 0.9 * e;
        rig.legL.rotation.x *= 0.9;
        rig.legR.rotation.x *= 0.9;
        if (z.deathT > 10.5) {
          this.scene.remove(g);
          rig.mats.forEach((m) => m.dispose());
          this.zombies.splice(i, 1);
        }
        continue;
      }

      z.stagger = Math.max(0, z.stagger - dt);
      z.phase += dt * (z.speed * 2.3 + 1.2);
      z.wobble += dt;

      if (z.state === "idle") {
        rig.legL.rotation.x = 0;
        rig.legR.rotation.x = 0;
        rig.armL.rotation.x = -0.15 + Math.sin(z.wobble * 0.8) * 0.08;
        rig.armR.rotation.x = -0.1 + Math.cos(z.wobble * 0.7) * 0.08;
        rig.lean.rotation.x = 0.2 + Math.sin(z.wobble * 0.6) * 0.05;
        rig.head.rotation.z = Math.sin(z.wobble * 0.5) * 0.25;
        rig.head.rotation.x = 0.35;
        g.rotation.y = z.yaw + Math.sin(z.wobble * 0.3) * 0.2;
        continue;
      }

      if (!active) continue;

      const dx = px - z.x;
      const dz = pz - z.z;
      const dist = Math.hypot(dx, dz) || 0.001;
      const target = Math.atan2(dx, dz);
      const diff = wrapAngle(target - z.yaw);
      const turn = (z.type === "runner" ? 8 : 5) * dt;
      z.yaw += Math.max(-turn, Math.min(turn, diff));

      // attack logic
      if (!z.attacking && dist < z.reach && z.attackCd <= 0 && this.state === "playing") {
        z.attacking = true;
        z.attackT = 0;
        z.hitDone = false;
      }
      z.attackCd -= dt;
      if (z.attacking) {
        z.attackT += dt;
        if (z.attackT >= 0.45 && !z.hitDone) {
          z.hitDone = true;
          if (dist < z.reach + 0.6 && this.state === "playing") this.hurtPlayer(z.dmg, z.x, z.z);
        }
        if (z.attackT >= 0.9) {
          z.attacking = false;
          z.attackCd = 0.35 + this.rnd() * 0.5;
        }
      }

      // movement
      const moving = !z.attacking && dist > z.reach * 0.75;
      if (moving) {
        const sp = this.freezeZombies ? 0 : z.speed * (z.stagger > 0 ? 0.25 : 1);
        tmp.x = z.x + (dx / dist) * sp * dt;
        tmp.z = z.z + (dz / dist) * sp * dt;
        // separation from others
        for (const o of this.zombies) {
          if (o === z || o.state === "dying") continue;
          const ox = tmp.x - o.x;
          const oz = tmp.z - o.z;
          const rr = z.radius + o.radius;
          const d2 = ox * ox + oz * oz;
          if (d2 < rr * rr && d2 > 1e-6) {
            const d = Math.sqrt(d2);
            const push = (rr - d) * 0.5;
            tmp.x += (ox / d) * push;
            tmp.z += (oz / d) * push;
          }
        }
        if (this.resolve(tmp, z.radius)) {
          const nx = this.contactN.x;
          const nz = this.contactN.z;
          const head = (dx / dist) * nx + (dz / dist) * nz;
          if (head < -0.7) {
            tmp.x += -nz * z.side * sp * dt * 0.9;
            tmp.z += nx * z.side * sp * dt * 0.9;
            this.resolve(tmp, z.radius);
          }
        }
        z.x = tmp.x;
        z.z = tmp.z;
      } else {
        // keep out of the player
        const d = Math.hypot(px - z.x, pz - z.z);
        if (d < 0.7 && d > 0.001) {
          z.x -= ((px - z.x) / d) * (0.7 - d);
          z.z -= ((pz - z.z) / d) * (0.7 - d);
        }
      }

      g.position.x = z.x;
      g.position.z = z.z;
      g.position.y = moving ? Math.abs(Math.sin(z.phase)) * 0.04 : 0;
      g.rotation.y = z.yaw;

      // animation
      const sw = moving ? 0.75 : 0;
      rig.legL.rotation.x = Math.sin(z.phase) * sw;
      rig.legR.rotation.x = -Math.sin(z.phase) * sw;
      const run = z.type === "runner";
      let armBase = run ? -1.15 : -1.45;
      if (z.attacking) {
        const u = z.attackT / 0.9;
        armBase = u < 0.5 ? -1.45 - u * 1.1 : -2.0 + (u - 0.5) * 2 * 1.5;
      }
      rig.armL.rotation.x = armBase + Math.sin(z.phase) * 0.14;
      rig.armR.rotation.x = armBase - Math.sin(z.phase) * 0.14;
      rig.armL.rotation.z = 0.08;
      rig.armR.rotation.z = -0.08;
      rig.lean.rotation.x = (run ? 0.42 : 0.14) + (z.attacking ? 0.2 * Math.sin((z.attackT / 0.9) * Math.PI) : 0);
      rig.head.rotation.x = 0.15 + Math.sin(z.phase * 0.5) * 0.06;
      rig.head.rotation.z = Math.sin(z.phase * 0.5) * 0.14;

      // groan
      z.groanT -= dt;
      if (z.groanT <= 0) {
        z.groanT = (z.type === "runner" ? 2.5 : 4) + this.rnd() * 6;
        if (dist < 48 && this.state === "playing") {
          this.audio?.groan(dist, this.panFor(z.x, z.z), z.type === "runner" ? 1.35 : 0.85 + this.rnd() * 0.5, z.type === "brute");
        }
      }
    }
  }

  private hitZombie(z: Zombie, dmg: number, head: boolean, point: THREE.Vector3, dir: THREE.Vector3, knock: number, silent = false) {
    if (z.state === "dying") return;
    const total = dmg * (head ? 2.5 : 1);
    z.hp -= total;
    z.flash = 1;
    z.stagger = z.type === "brute" ? 0.04 : 0.2;
    z.x += dir.x * knock;
    z.z += dir.z * knock;
    this.resolve(z, z.radius);
    this.emitBlood(point, dir, head ? 16 : 9);
    if (!silent) {
      const pan = this.panFor(z.x, z.z);
      if (head) this.audio?.headshot(pan);
      else this.audio?.zombieHit(pan);
    }
    this.hits++;
    if (z.hp <= 0) {
      this.killZombie(z, head);
    } else {
      this.ev.onHit(head, false, 0);
    }
  }

  private killZombie(z: Zombie, head: boolean) {
    z.state = "dying";
    z.deathT = 0;
    z.attacking = false;
    this.kills++;
    let pts = z.score;
    if (head) {
      pts += 50;
      this.headshots++;
    }
    this.score += pts;
    this.ev.onHit(head, true, pts);
    this.audio?.zombieDie(Math.hypot(z.x - this.pos.x, z.z - this.pos.z), this.panFor(z.x, z.z));
    this.emitDecal(z.x, z.z, 1.6 + this.rnd() * 1.2);
    // drops
    const r = this.rnd();
    if (this.pickups.length < 14) {
      if (r < 0.14) this.spawnPickup("ammo", z.x, z.z);
      else if (r < 0.2) this.spawnPickup("health", z.x, z.z);
    }
    if (z.type === "brute") {
      this.spawnPickup("health", z.x + 1, z.z);
      this.spawnPickup("ammo", z.x - 1, z.z);
    }
  }

  private hurtPlayer(dmg: number, fx: number, fz: number) {
    if (this.godMode || this.hp <= 0) return;
    this.hp -= dmg;
    this.shake = Math.min(1.5, this.shake + 0.6);
    this.audio?.hurt();
    const dx = fx - this.pos.x;
    const dz = fz - this.pos.z;
    const f = { x: -Math.sin(this.yaw), z: -Math.cos(this.yaw) };
    const r = { x: Math.cos(this.yaw), z: -Math.sin(this.yaw) };
    const ang = Math.atan2(dx * r.x + dz * r.z, dx * f.x + dz * f.z);
    this.ev.onHurt(ang, dmg);
    if (this.hp <= 0) {
      this.hp = 0;
      this.state = "dead";
      this.deathT = 0;
      this.fireHeld = false;
      this.audio?.death();
      if (document.pointerLockElement) document.exitPointerLock();
    }
  }

  /* ================================================================ */
  /* Waves                                                              */
  /* ================================================================ */

  private updateWaves(dt: number) {
    if (this.waveState === "break") {
      this.breakT -= dt;
      if (this.breakT <= 0) {
        this.wave++;
        this.waveState = "active";
        const total = 6 + this.wave * 3;
        const list: ZType[] = [];
        const brutes = this.wave >= 3 ? Math.floor(this.wave / 3) : 0;
        const runnerP = this.wave < 2 ? 0 : Math.min(0.45, 0.1 + this.wave * 0.05);
        for (let i = 0; i < total; i++) list.push(this.rnd() < runnerP ? "runner" : "walker");
        for (let i = 0; i < brutes; i++) list.splice(Math.floor(this.rnd() * list.length), 0, "brute");
        this.toSpawn = list;
        this.spawnT = 0.5;
        const sub =
          this.wave === 1 ? "Eles estão vindo..." : this.wave % 3 === 0 ? "Algo enorme se aproxima!" : this.wave >= 4 ? "Os corredores estão mais rápidos." : "Mantenha-se em movimento.";
        this.ev.onWave(this.wave, `ONDA ${this.wave}`, sub);
        this.audio?.waveStart();
      }
    } else {
      this.spawnT -= dt;
      if (this.toSpawn.length > 0 && this.spawnT <= 0 && this.aliveCount() < 28) {
        const [x, z] = this.findSpawnPoint();
        this.spawnZombie(this.toSpawn.shift()!, x, z);
        this.spawnT = Math.max(0.3, 1.5 - this.wave * 0.08);
      }
      if (this.toSpawn.length === 0 && this.aliveCount() === 0) {
        this.waveState = "break";
        this.breakT = 12;
        const bonus = this.wave * 250;
        this.score += bonus;
        this.audio?.waveClear();
        this.ev.onWave(this.wave, "ONDA SUPERADA", `Bônus +${bonus}  •  Suprimentos lançados no mapa`);
        for (let i = 0; i < 2; i++) {
          const [x, z] = this.randomFreePoint(10);
          this.spawnPickup("ammo", x, z);
        }
        const [hx, hz] = this.randomFreePoint(10);
        this.spawnPickup("health", hx, hz);
        if (this.wave % 2 === 0) {
          const [h2x, h2z] = this.randomFreePoint(10);
          this.spawnPickup("health", h2x, h2z);
        }
      }
    }
  }

  /* ================================================================ */
  /* Pickups                                                            */
  /* ================================================================ */

  private spawnPickup(kind: PickupKind, x: number, z: number) {
    const p = createPickup(kind, this.T);
    p.root.position.set(x, 0, z);
    this.scene.add(p.root);
    this.pickups.push({ kind, root: p.root, float: p.float, x, z, t: this.rnd() * 6 });
  }

  private clearPickups() {
    for (const p of this.pickups) this.scene.remove(p.root);
    this.pickups = [];
  }

  private updatePickups(dt: number) {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.t += dt;
      p.float.rotation.y += dt * 1.6;
      p.float.position.y = 1.0 + Math.sin(p.t * 2.2) * 0.12;
      if (this.state !== "playing") continue;
      const d = Math.hypot(p.x - this.pos.x, p.z - this.pos.z);
      if (d > 1.7) continue;
      let take = true;
      if (p.kind === "ammo") {
        for (let w = 0; w < 3; w++) if (this.owned[w]) this.reserves[w] = Math.min(WEAPONS[w].maxReserve, this.reserves[w] + WEAPONS[w].pack);
        this.ev.onMessage("Munição recolhida", "good");
        this.audio?.pickup();
      } else if (p.kind === "health") {
        if (this.hp >= 100) take = false;
        else {
          this.hp = Math.min(100, this.hp + 40);
          this.ev.onMessage("+40 de vida", "good");
          this.audio?.pickup();
        }
      } else {
        const w = p.kind === "shotgun" ? 1 : 2;
        const def = WEAPONS[w];
        if (this.owned[w]) {
          this.reserves[w] = Math.min(def.maxReserve, this.reserves[w] + def.pack * 2);
          this.ev.onMessage(`Munição de ${def.name}`, "good");
        } else {
          this.owned[w] = true;
          this.mags[w] = def.mag;
          this.reserves[w] = def.pack * 2;
          this.ev.onMessage(`${def.name} adquirida!`, "good");
          this.switchTo(w);
        }
        this.audio?.weaponPickup();
      }
      if (take) {
        this.scene.remove(p.root);
        this.pickups.splice(i, 1);
      }
    }
  }

  /* ================================================================ */
  /* Weapons                                                            */
  /* ================================================================ */

  private switchTo(i: number) {
    if (i === this.cur || !this.owned[i] || this.melee.active) return;
    this.cur = i;
    this.reloading = false;
    this.switchT = 1;
    this.guns.forEach((g, k) => (g.group.visible = k === i));
    this.audio?.click();
  }

  private startReload() {
    const d = WEAPONS[this.cur];
    if (this.reloading || this.melee.active || this.mags[this.cur] >= d.mag || this.reserves[this.cur] <= 0) return;
    this.reloading = true;
    this.reloadT = d.reload;
    this.audio?.reload(d.reload);
  }

  private startMelee() {
    if (this.melee.active || this.melee.cd > 0) return;
    this.melee.active = true;
    this.melee.t = 0;
    this.melee.hit = false;
    this.reloading = false;
    this.audio?.swing();
  }

  private updateMelee(dt: number) {
    const m = this.melee;
    m.cd = Math.max(0, m.cd - dt);
    if (!m.active) return;
    m.t += dt / 0.55;
    if (m.t >= 0.45 && !m.hit) {
      m.hit = true;
      const fwd = this.tmpV.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
      let count = 0;
      for (const z of this.zombies) {
        if (z.state === "dying") continue;
        const dx = z.x - this.pos.x;
        const dz = z.z - this.pos.z;
        const d = Math.hypot(dx, dz);
        if (d > 2.4 + z.radius) continue;
        if ((dx * fwd.x + dz * fwd.z) / (d || 1) < 0.45) continue;
        const dir = new V3(dx / (d || 1), 0, dz / (d || 1));
        const pt = new V3(z.x, 1.3, z.z);
        this.hitZombie(z, 55, false, pt, dir, 1.0, true);
        count++;
        if (count >= 3) break;
      }
      if (count > 0) {
        this.audio?.melee();
        this.shake += 0.35;
      }
    }
    if (m.t >= 1) {
      m.active = false;
      m.cd = 0.15;
    }
  }

  private emitTracer(a: THREE.Vector3, b: THREE.Vector3) {
    const t = this.tracers.find((x) => x.life <= 0);
    if (!t) return;
    const dir = this.tmpV2.copy(b).sub(a);
    const len = dir.length();
    if (len < 0.1) return;
    dir.normalize();
    t.mesh.position.copy(a).addScaledVector(dir, len / 2);
    t.mesh.scale.set(1, 1, len);
    t.mesh.quaternion.setFromUnitVectors(Z_AXIS, dir);
    t.mesh.visible = true;
    t.life = 0.07;
    (t.mesh.material as THREE.MeshBasicMaterial).opacity = 0.8;
  }

  private castRay(o: THREE.Vector3, d: THREE.Vector3, maxT: number) {
    let tBest = maxT;
    let kind: "none" | "wall" | "ground" | "zombie" | "barrel" = "none";
    let barrel: BarrelObj | undefined;
    let zombie: Zombie | undefined;
    let head = false;
    for (const c of this.world.colliders) {
      const t = rayBox(o, d, c, tBest);
      if (t !== null && t < tBest) {
        tBest = t;
        kind = c.barrel ? "barrel" : "wall";
        barrel = c.barrel;
      }
    }
    if (d.y < -1e-4) {
      const t = -o.y / d.y;
      if (t > 0 && t < tBest) {
        tBest = t;
        kind = "ground";
      }
    }
    for (const z of this.zombies) {
      if (z.state === "dying") continue;
      const s = z.rig.group.scale.y;
      const cx = z.x - o.x;
      const cy = 1.0 * s - o.y;
      const cz = z.z - o.z;
      const proj = cx * d.x + cy * d.y + cz * d.z;
      if (proj < 0 || proj - 2 > tBest) continue;
      const d2 = cx * cx + cy * cy + cz * cz - proj * proj;
      if (d2 > (1.5 * s) * (1.5 * s)) continue;
      this.raycaster.set(o, d);
      this.raycaster.far = tBest;
      const hits = this.raycaster.intersectObjects(z.rig.meshes, false);
      if (hits.length && hits[0].distance < tBest) {
        tBest = hits[0].distance;
        kind = "zombie";
        zombie = z;
        head = hits[0].object.userData.part === "head";
      }
    }
    return { t: tBest, kind, barrel, zombie, head };
  }

  private shoot() {
    const def = WEAPONS[this.cur];
    if (this.infiniteAmmo) {
      this.mags[this.cur] = def.mag;
      this.reserves[this.cur] = def.maxReserve;
    } else {
      this.mags[this.cur]--;
    }
    this.cooldown = def.rate;
    this.shots++;
    this.audio?.shot(def.id);
    this.recoilV = Math.min(1.6, this.recoilV + def.recoil * 0.5);
    this.flashT = 0.055;
    this.pumpT = def.id === "shotgun" ? 0.65 : 0;
    this.muzzleLight.intensity = 90;
    this.shake += def.id === "shotgun" ? 0.35 : 0.08;
    this.pitch += def.recoil * 0.0085 * (0.7 + this.rnd() * 0.6);
    this.yaw += (this.rnd() - 0.5) * def.recoil * 0.006;

    const origin = this.camera.position.clone();
    const fwd = new V3(-Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), -Math.cos(this.yaw) * Math.cos(this.pitch));
    const right = new V3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const up = new V3().crossVectors(right, fwd).normalize();
    const moving = this.vel.length() > 1;
    const spread = def.spread * (moving ? 1.8 : 1) * (this.onGround ? 1 : 2.5);
    const muzzle = this.guns[this.cur].muzzle.clone();
    this.guns[this.cur].group.localToWorld(muzzle);

    for (let p = 0; p < def.pellets; p++) {
      const a = this.rnd() * Math.PI * 2;
      const r = Math.sqrt(this.rnd()) * spread;
      const dir = fwd.clone().addScaledVector(right, Math.cos(a) * r).addScaledVector(up, Math.sin(a) * r).normalize();
      const res = this.castRay(origin, dir, 120);
      const pt = origin.clone().addScaledVector(dir, res.t);
      if (def.pellets === 1 || p % 3 === 0) this.emitTracer(muzzle, pt);
      const fall = def.id === "shotgun" ? Math.max(0.25, 1 - res.t / 28) : 1;
      if (res.kind === "zombie" && res.zombie) {
        this.hitZombie(res.zombie, def.dmg * fall, res.head, pt, dir, def.id === "shotgun" ? 0.12 : 0.05);
      } else if (res.kind === "barrel" && res.barrel) {
        this.emitSparks(pt, dir, 6);
        res.barrel.hp -= def.dmg;
        if (res.barrel.hp <= 0) this.explode(res.barrel);
      } else if (res.kind === "wall") {
        this.emitSparks(pt, dir, 5);
        this.emitSmoke(pt, 1, 0.6, 0x888888);
      } else if (res.kind === "ground") {
        this.emitSmoke(pt, 2, 0.8, 0x6a6a55);
      }
    }
    if (this.mags[this.cur] <= 0 && this.reserves[this.cur] > 0) {
      setTimeout(() => {
        if (this.state === "playing") this.startReload();
      }, 250);
    }
  }

  private updateWeapons(dt: number) {
    const def = WEAPONS[this.cur];
    this.cooldown -= dt;
    this.fireBuf -= dt;
    this.switchT = Math.max(0, this.switchT - dt / 0.35);
    this.flashT -= dt;
    this.muzzleLight.intensity *= Math.exp(-dt * 40);
    if (this.muzzleLight.intensity < 0.5) this.muzzleLight.intensity = 0;
    this.pumpT = Math.max(0, this.pumpT - dt);

    if (this.reloading) {
      this.reloadT -= dt;
      if (this.reloadT <= 0) {
        this.reloading = false;
        const need = def.mag - this.mags[this.cur];
        const take = Math.min(need, this.reserves[this.cur]);
        this.mags[this.cur] += take;
        this.reserves[this.cur] -= take;
      }
    }

    const want = def.auto ? this.fireHeld : this.fireBuf > 0;
    if (want && this.cooldown <= 0 && !this.reloading && this.switchT <= 0.4 && !this.melee.active) {
      if (this.mags[this.cur] > 0) {
        this.shoot();
        this.fireBuf = 0;
      } else {
        this.cooldown = 0.3;
        this.fireBuf = 0;
        if (this.reserves[this.cur] > 0) this.startReload();
        else {
          this.audio?.click();
          this.ev.onMessage("Sem munição! Troque de arma (1-3) ou use V para corpo a corpo.", "bad");
        }
      }
    }
    if (def.id === "shotgun" && this.pumpT > 0.2 && this.pumpT - dt <= 0.2) this.audio?.pump();
  }

  /* ================================================================ */
  /* Explosions & particles                                             */
  /* ================================================================ */

  private explode(b: BarrelObj) {
    if (b.dead) return;
    b.dead = true;
    b.obj.visible = false;
    const idx = this.world.colliders.indexOf(b.col);
    if (idx >= 0) this.world.colliders.splice(idx, 1);
    const pos = new V3(b.x, 0.6, b.z);
    const sc = new THREE.Mesh(
      new THREE.PlaneGeometry(4, 4),
      new THREE.MeshBasicMaterial({ map: this.T.scorch, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -7, polygonOffsetUnits: -7 })
    );
    sc.rotation.x = -Math.PI / 2;
    sc.rotation.z = this.rnd() * 6;
    sc.position.set(b.x, 0.065, b.z);
    this.scene.add(sc);
    this.scorches.push(sc);

    for (let i = 0; i < 34; i++) {
      const v = new V3((this.rnd() - 0.5) * 7, 2 + this.rnd() * 9, (this.rnd() - 0.5) * 7);
      this.emitFire(pos, v, 1.8 + this.rnd() * 2.2, 5 + this.rnd() * 4, 0.55 + this.rnd() * 0.6, 0xffe080, 0xff3a10, 1.0);
    }
    for (let i = 0; i < 20; i++) {
      const v = new V3((this.rnd() - 0.5) * 4, 1 + this.rnd() * 4, (this.rnd() - 0.5) * 4);
      this.emitSprite(this.smokePool, pos, v, 1.5, 6 + this.rnd() * 3, 1.8 + this.rnd() * 1.5, 0x222222, 0x222222, 0.7, 1.2, 1.5);
    }
    for (let i = 0; i < 36; i++) {
      const v = new V3((this.rnd() - 0.5) * 18, 3 + this.rnd() * 12, (this.rnd() - 0.5) * 18);
      this.emitBox(pos, v, i % 3 === 0 ? "debris" : "ember", 0.05 + this.rnd() * 0.12, 0.8 + this.rnd() * 1.2, -18);
    }
    this.boomT = 1;
    this.boomLight.position.set(b.x, 2.5, b.z);
    const dpl = Math.hypot(b.x - this.pos.x, b.z - this.pos.z);
    this.audio?.explosion(dpl);
    this.shake += Math.max(0, 1.6 - dpl / 25);

    const R = 8.5;
    for (const z of this.zombies) {
      if (z.state === "dying") continue;
      const dx = z.x - b.x;
      const dz = z.z - b.z;
      const d = Math.hypot(dx, dz);
      if (d > R) continue;
      const dir = new V3(dx / (d || 1), 0.2, dz / (d || 1));
      this.hitZombie(z, 40 + 260 * (1 - d / R), false, new V3(z.x, 1.2, z.z), dir, 2.2 * (1 - d / R) + 0.3, true);
    }
    if (dpl < R && this.state === "playing") {
      this.hurtPlayer(Math.round(8 + 62 * (1 - dpl / R)), b.x, b.z);
    }
    for (const o of this.world.barrels) {
      if (o.dead) continue;
      if (Math.hypot(o.x - b.x, o.z - b.z) < 6.5 && !this.pendingBlasts.find((p) => p.b === o)) {
        this.pendingBlasts.push({ b: o, t: 0.12 + this.rnd() * 0.25 });
      }
    }
  }

  private emitBox(pos: THREE.Vector3, vel: THREE.Vector3, mat: string, size: number, life: number, grav: number) {
    const p = this.boxPool.find((x) => !x.active);
    if (!p) return;
    p.active = true;
    p.mesh.material = this.boxMats[mat];
    p.mesh.position.copy(pos);
    p.vel.copy(vel);
    p.life = life;
    p.max = life;
    p.grav = grav;
    p.size = size;
    p.mesh.scale.setScalar(size);
    p.mesh.visible = true;
  }

  private emitSprite(
    pool: SpriteP[],
    pos: THREE.Vector3,
    vel: THREE.Vector3,
    s0: number,
    s1: number,
    life: number,
    c0: number,
    c1: number,
    op: number,
    rise: number,
    drag: number
  ) {
    const p = pool.find((x) => !x.active);
    if (!p) return;
    p.active = true;
    p.sprite.position.copy(pos);
    p.vel.copy(vel);
    p.life = life;
    p.max = life;
    p.s0 = s0;
    p.s1 = s1;
    p.op = op;
    p.rise = rise;
    p.drag = drag;
    p.c0.set(c0);
    p.c1.set(c1);
    p.sprite.material.rotation = this.rnd() * 6.28;
    p.sprite.visible = true;
  }

  private emitFire(pos: THREE.Vector3, vel: THREE.Vector3, s0: number, s1: number, life: number, c0: number, c1: number, op: number) {
    this.emitSprite(this.firePool, pos, vel, s0, s1, life, c0, c1, op, 0.5, 1.2);
  }

  private emitSmoke(pos: THREE.Vector3, n: number, size: number, color: number) {
    for (let i = 0; i < n; i++) {
      const v = new V3((this.rnd() - 0.5) * 0.8, 0.3 + this.rnd() * 0.8, (this.rnd() - 0.5) * 0.8);
      this.emitSprite(this.smokePool, pos, v, size * 0.5, size * 2.2, 0.7 + this.rnd() * 0.5, color, color, 0.35, 0.2, 2);
    }
  }

  private emitSparks(pos: THREE.Vector3, dir: THREE.Vector3, n: number) {
    for (let i = 0; i < n; i++) {
      const v = new V3((this.rnd() - 0.5) * 3, this.rnd() * 3, (this.rnd() - 0.5) * 3).addScaledVector(dir, -2);
      this.emitBox(pos, v, "spark", 0.02 + this.rnd() * 0.02, 0.25 + this.rnd() * 0.25, -12);
    }
  }

  private emitBlood(pos: THREE.Vector3, dir: THREE.Vector3, n: number) {
    for (let i = 0; i < n; i++) {
      const v = new V3((this.rnd() - 0.5) * 3.5, this.rnd() * 3.5 + 0.5, (this.rnd() - 0.5) * 3.5).addScaledVector(dir, 2.5);
      this.emitBox(pos, v, "blood", 0.03 + this.rnd() * 0.05, 0.5 + this.rnd() * 0.6, -14);
    }
    if (this.rnd() < 0.35) this.emitDecal(pos.x + dir.x * 0.8, pos.z + dir.z * 0.8, 0.6 + this.rnd() * 0.7);
  }

  private emitDecal(x: number, z: number, size: number) {
    const d = this.decals[this.decalIdx++ % this.decals.length];
    d.mesh.position.set(x, 0.06 + (this.decalIdx % 7) * 0.002, z);
    d.mesh.rotation.z = this.rnd() * 6.28;
    d.mesh.scale.setScalar(size);
    d.life = 45;
    d.max = 45;
    d.mesh.visible = true;
    (d.mesh.material as THREE.MeshBasicMaterial).opacity = 1;
  }

  private updateParticles(dt: number) {
    for (const p of this.boxPool) {
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      p.vel.y += p.grav * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      if (p.mesh.position.y < 0.03) {
        p.mesh.position.y = 0.03;
        p.vel.multiplyScalar(0.3);
        p.vel.y = 0;
      }
      p.mesh.scale.setScalar(p.size * Math.min(1, (p.life / p.max) * 2));
    }
    const upd = (pool: SpriteP[], fire: boolean) => {
      for (const p of pool) {
        if (!p.active) continue;
        p.life -= dt;
        if (p.life <= 0) {
          p.active = false;
          p.sprite.visible = false;
          continue;
        }
        const k = 1 - p.life / p.max;
        p.vel.multiplyScalar(Math.max(0, 1 - p.drag * dt));
        p.vel.y += p.rise * dt;
        p.sprite.position.addScaledVector(p.vel, dt);
        const s = p.s0 + (p.s1 - p.s0) * k;
        p.sprite.scale.set(s, s, 1);
        const m = p.sprite.material;
        m.color.copy(p.c0).lerp(p.c1, k);
        m.opacity = p.op * (fire ? (1 - k) * (1 - k) : Math.sin(Math.min(1, k * 4) * Math.PI * 0.5) * (1 - k));
      }
    };
    upd(this.smokePool, false);
    upd(this.firePool, true);
    for (const d of this.decals) {
      if (!d.mesh.visible) continue;
      d.life -= dt;
      if (d.life <= 0) d.mesh.visible = false;
      else (d.mesh.material as THREE.MeshBasicMaterial).opacity = Math.min(1, d.life / 8);
    }
    for (const t of this.tracers) {
      if (t.life <= 0) continue;
      t.life -= dt;
      if (t.life <= 0) t.mesh.visible = false;
      else (t.mesh.material as THREE.MeshBasicMaterial).opacity = (t.life / 0.07) * 0.8;
    }
    for (let i = this.pendingBlasts.length - 1; i >= 0; i--) {
      this.pendingBlasts[i].t -= dt;
      if (this.pendingBlasts[i].t <= 0) {
        const b = this.pendingBlasts[i].b;
        this.pendingBlasts.splice(i, 1);
        this.explode(b);
      }
    }
    if (this.boomT > 0) {
      this.boomT = Math.max(0, this.boomT - dt * 2.2);
      this.boomLight.intensity = 900 * this.boomT * this.boomT;
    }
  }

  /* ================================================================ */
  /* Environment                                                        */
  /* ================================================================ */

  private updateEnv(dt: number, time: number) {
    // sky follows camera
    this.skyGroup.position.copy(this.camera.position);

    // rain
    const cam = this.camera.position;
    const N = this.rainBase.length / 3;
    for (let i = 0; i < N; i++) {
      let x = this.rainBase[i * 3];
      let y = this.rainBase[i * 3 + 1] - 30 * dt;
      let z = this.rainBase[i * 3 + 2];
      x += 2.5 * dt;
      if (y < 0) y += 26;
      if (x < cam.x - 24) x += 48;
      else if (x > cam.x + 24) x -= 48;
      if (z < cam.z - 24) z += 48;
      else if (z > cam.z + 24) z -= 48;
      this.rainBase[i * 3] = x;
      this.rainBase[i * 3 + 1] = y;
      this.rainBase[i * 3 + 2] = z;
      const o = i * 6;
      this.rainPos[o] = x;
      this.rainPos[o + 1] = y;
      this.rainPos[o + 2] = z;
      this.rainPos[o + 3] = x - 0.07;
      this.rainPos[o + 4] = y + 0.9;
      this.rainPos[o + 5] = z;
    }
    (this.rain.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;

    // lightning
    this.nextLightning -= dt;
    if (this.nextLightning <= 0) {
      this.nextLightning = 14 + this.rnd() * 22;
      this.lightningT = 0.55;
      this.audio?.thunder(0.4 + this.rnd() * 1.8);
    }
    if (this.lightningT > 0) {
      this.lightningT -= dt;
      const t = this.lightningT;
      const pulse = t > 0.4 ? 1 : t > 0.3 ? 0.1 : t > 0.15 ? 0.8 : t * 3;
      this.lightningPulse = Math.max(0, pulse);
    } else this.lightningPulse = 0;
    this.skyMat.uniforms.flash.value = this.lightningPulse * 0.6;
    this.hemi.intensity = 1.0 + this.lightningPulse * 3.2;
    this.moon.intensity = 1.5 + this.lightningPulse * 2;

    // fires
    for (const f of this.world.fires) {
      f.t += dt;
      if (f.light) f.light.intensity = 26 + Math.sin(time * 13 + f.seed) * 6 + Math.sin(time * 31 + f.seed * 2) * 4;
      if (Math.random() < dt * 28) {
        const v = new V3((Math.random() - 0.5) * 0.5, 1.2 + Math.random() * 1.2, (Math.random() - 0.5) * 0.5);
        this.emitFire(f.pos, v, 0.7, 0.2, 0.5 + Math.random() * 0.3, 0xffd060, 0xff3010, 0.9);
      }
      if (Math.random() < dt * 5) {
        const v = new V3((Math.random() - 0.5) * 0.4, 1.0, (Math.random() - 0.5) * 0.4);
        this.emitSprite(this.smokePool, f.pos, v, 0.6, 2.4, 2.5, 0x1a1a1a, 0x1a1a1a, 0.5, 0.8, 0.4);
      }
    }
    for (const l of this.world.lampLights) {
      l.light.intensity = l.flicker ? l.base * (Math.sin(time * 40) > 0.6 && Math.sin(time * 3.1) > 0.2 ? 0.2 : 1) : l.base;
    }
  }

  /* ================================================================ */
  /* Main loop                                                          */
  /* ================================================================ */

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    let dt = (now - this.last) / 1000;
    this.last = now;
    dt = Math.min(dt, 0.05);
    this.step(dt, now / 1000);
    this.renderer.render(this.scene, this.camera);
  };

  private step(dt: number, time: number) {
    if (this.state === "paused") return;
    if (this.state === "menu") {
      this.menuT += dt * 0.07;
      this.camera.position.set(Math.cos(this.menuT) * 15, 4.2 + Math.sin(this.menuT * 2) * 0.6, Math.sin(this.menuT) * 15);
      this.camera.lookAt(0, 1.8, 0);
      this.vm.visible = false;
      this.updateZombies(dt, false);
      this.updateEnv(dt, time);
      this.updateParticles(dt);
      this.moon.position.set(-30, 50, -25);
      this.moon.target.position.set(0, 0, 0);
      this.moon.target.updateMatrixWorld();
      return;
    }
    this.vm.visible = this.state === "playing";

    if (this.state === "playing") {
      this.time += dt;
      this.updatePlayer(dt);
      this.updateWeapons(dt);
      this.updateMelee(dt);
      this.updateWaves(dt);
    } else if (this.state === "dead") {
      this.deathT += dt;
      this.camera.position.y += (0.35 - this.camera.position.y) * Math.min(1, dt * 4);
      this.camera.rotation.z += (0.9 - this.camera.rotation.z) * Math.min(1, dt * 3);
      this.camera.rotation.x += (-0.35 - this.camera.rotation.x) * Math.min(1, dt * 2);
      if (this.deathT > 2.2 && !this.deadReported) {
        this.deadReported = true;
        this.ev.onDead({ score: this.score, kills: this.kills, wave: this.wave, headshots: this.headshots, shots: this.shots, hits: this.hits, time: this.time });
      }
    }
    this.updateZombies(dt, true);
    this.updatePickups(dt);
    this.updateEnv(dt, time);
    this.updateParticles(dt);
    if (this.state === "playing") this.updateViewmodel(dt);

    this.moon.position.set(this.pos.x - 30, 50, this.pos.z - 25);
    this.moon.target.position.set(this.pos.x, 0, this.pos.z);
    this.moon.target.updateMatrixWorld();

    this.hudAcc += dt;
    if (this.hudAcc > 0.05) {
      this.hudAcc = 0;
      this.pushHud();
    }
    this.radarAcc += dt;
    if (this.radarAcc > 0.06) {
      this.radarAcc = 0;
      this.drawRadar();
    }
  }

  private updatePlayer(dt: number) {
    const k = this.keys;
    // keyboard look
    const lookS = 2.0 * dt;
    if (k.ArrowLeft) this.yaw += lookS;
    if (k.ArrowRight) this.yaw -= lookS;
    if (k.ArrowUp) this.pitch = Math.min(1.5, this.pitch + lookS);
    if (k.ArrowDown) this.pitch = Math.max(-1.5, this.pitch - lookS);

    let ix = 0;
    let iz = 0;
    if (k.KeyW) iz -= 1;
    if (k.KeyS) iz += 1;
    if (k.KeyA) ix -= 1;
    if (k.KeyD) ix += 1;
    const moving = ix !== 0 || iz !== 0;
    const len = Math.hypot(ix, iz) || 1;
    ix /= len;
    iz /= len;

    const wantSprint = (k.ShiftLeft || k.ShiftRight) && moving && iz <= 0 && !this.exhausted && !this.reloading;
    const sprinting = !!wantSprint && this.stamina > 0;
    if (sprinting) {
      if (!this.infiniteStamina) {
        this.stamina = Math.max(0, this.stamina - 22 * dt);
        if (this.stamina <= 0) this.exhausted = true;
      } else {
        this.stamina = 100;
      }
      this.staminaDelay = 0.9;
    } else {
      this.staminaDelay -= dt;
      if (this.staminaDelay <= 0) this.stamina = Math.min(100, this.stamina + 16 * dt);
      if (this.exhausted && this.stamina > 25) this.exhausted = false;
    }
    this.sprintB += ((sprinting ? 1 : 0) - this.sprintB) * Math.min(1, dt * 8);

    const speed = (sprinting ? 8.4 : 5.0) * this.speedMul;
    const sinY = Math.sin(this.yaw);
    const cosY = Math.cos(this.yaw);
    const wx = ix * cosY + iz * sinY;
    const wz = -ix * sinY + iz * cosY;
    const tx = wx * speed;
    const tz = wz * speed;
    const acc = this.onGround ? 14 : 3;
    this.vel.x += (tx - this.vel.x) * Math.min(1, acc * dt);
    this.vel.z += (tz - this.vel.z) * Math.min(1, acc * dt);

    if (k.Space && this.onGround) {
      this.vel.y = 6.6;
      this.onGround = false;
    }
    this.vel.y -= 20 * dt;
    this.pos.y += this.vel.y * dt;
    if (this.pos.y <= 0) {
      this.pos.y = 0;
      if (!this.onGround && this.vel.y < -3) this.audio?.step(true);
      this.vel.y = 0;
      this.onGround = true;
    }

    const p = { x: this.pos.x + this.vel.x * dt, z: this.pos.z + this.vel.z * dt };
    this.resolve(p, 0.42);
    // zombies push player back softly
    for (const z of this.zombies) {
      if (z.state === "dying" || z.state === "idle") continue;
      const dx = p.x - z.x;
      const dz = p.z - z.z;
      const rr = 0.42 + z.radius * 0.8;
      const d2 = dx * dx + dz * dz;
      if (d2 < rr * rr && d2 > 1e-6) {
        const d = Math.sqrt(d2);
        p.x += (dx / d) * (rr - d) * 0.6;
        p.z += (dz / d) * (rr - d) * 0.6;
      }
    }
    this.resolve(p, 0.42);
    this.pos.x = p.x;
    this.pos.z = p.z;

    const hSpeed = Math.hypot(this.vel.x, this.vel.z);
    const moveAmt = this.onGround ? Math.min(1, hSpeed / 5) : 0;
    this.bobPhase += hSpeed * dt * (sprinting ? 1.25 : 1.5);
    if (this.onGround && hSpeed > 1.5) {
      this.stepAcc += hSpeed * dt;
      const stride = sprinting ? 3.3 : 2.4;
      if (this.stepAcc > stride) {
        this.stepAcc = 0;
        this.audio?.step(sprinting);
      }
    }

    // low health heartbeat
    if (this.hp < 35) {
      this.heartT -= dt;
      if (this.heartT <= 0) {
        this.heartT = 0.35 + (this.hp / 35) * 0.8;
        this.audio?.heartbeat();
      }
    }

    // camera
    this.shake = Math.max(0, this.shake - dt * 3.2);
    const sh = this.shake;
    const bobY = Math.sin(this.bobPhase * 2) * 0.04 * moveAmt * (sprinting ? 1.4 : 1);
    const bobX = Math.sin(this.bobPhase) * 0.03 * moveAmt;
    this.camera.position.set(this.pos.x + Math.cos(this.yaw) * bobX, this.pos.y + EYE + bobY, this.pos.z - Math.sin(this.yaw) * bobX);
    this.camera.rotation.x = this.pitch + (Math.random() - 0.5) * sh * 0.03;
    this.camera.rotation.y = this.yaw + (Math.random() - 0.5) * sh * 0.03;
    this.camera.rotation.z = (Math.random() - 0.5) * sh * 0.02 + Math.sin(this.bobPhase) * 0.004 * moveAmt - ix * 0.012;
    const tf = 75 + this.sprintB * 8;
    if (Math.abs(tf - this.fov) > 0.05) {
      this.fov += (tf - this.fov) * Math.min(1, dt * 8);
      this.camera.fov = this.fov;
      this.camera.updateProjectionMatrix();
    }
    // sway decay
    this.swayX *= Math.exp(-dt * 8);
    this.swayY *= Math.exp(-dt * 8);
    this.recoilV *= Math.exp(-dt * 14);
    this.bobMove = moveAmt;
  }

  private bobMove = 0;

  private updateViewmodel(dt: number) {
    void dt;
    const i = this.cur;
    const g = this.guns[i];
    const base = VM_BASE[i];
    const def = WEAPONS[i];
    const moveAmt = this.bobMove;
    const bx = Math.sin(this.bobPhase) * 0.012 * moveAmt;
    const by = -Math.abs(Math.sin(this.bobPhase)) * 0.014 * moveAmt;
    let x = base[0] + bx;
    let y = base[1] + by;
    let z = base[2];
    let rx = 0;
    let ry = 0;
    let rz = 0;
    if (this.reloading) {
      const p = 1 - this.reloadT / def.reload;
      const r = Math.sin(Math.min(1, Math.max(0, p)) * Math.PI);
      y -= r * 0.15;
      rx -= r * 0.55;
      rz += r * 0.4;
      x -= r * 0.04;
    }
    y -= this.switchT * 0.35;
    rx -= this.switchT * 0.5;
    const s = this.sprintB;
    rx -= s * 0.3;
    ry += s * 0.6;
    y -= s * 0.05;
    x -= s * 0.04;
    z += this.recoilV * 0.07;
    rx += this.recoilV * 0.14;
    ry += this.swayX * 4;
    rx += this.swayY * 4;
    if (this.melee.active) y -= 0.6;
    g.group.position.set(x, y, z);
    g.group.rotation.set(rx, ry, rz);
    g.group.visible = !this.melee.active;
    this.flashSprites.forEach((fs, k) => {
      const m = fs.material;
      m.opacity = k === i && this.flashT > 0 ? 1 : 0;
      m.rotation = this.rnd() * 6;
    });
    if (g.pump) {
      const u = this.pumpT > 0 ? 1 - Math.max(0, (this.pumpT - 0.15) / 0.5) : 1;
      const off = this.pumpT > 0.15 ? Math.sin(Math.min(1, u) * Math.PI) * 0.13 : 0;
      g.pump.position.z = -0.34 + off;
      const hand = g.pump.userData.hand as THREE.Object3D | undefined;
      if (hand) hand.position.z = -0.36 + off;
    }
    // crowbar
    this.crowbar.visible = this.melee.active;
    if (this.melee.active) {
      const t = this.melee.t;
      let cx = 0.2;
      let cy = -0.25;
      const cz = -0.45;
      let crx = 0;
      let cry = 0;
      let crz = 0;
      if (t < 0.3) {
        const u = t / 0.3;
        crx = u * 0.9;
        cry = -u * 0.4;
        cy += u * 0.08;
        cx += u * 0.08;
      } else if (t < 0.6) {
        const u = (t - 0.3) / 0.3;
        const e = u * u;
        crx = 0.9 - e * 2.1;
        cry = -0.4 + e * 1.1;
        cx += 0.08 - e * 0.35;
        cy += 0.08 - e * 0.1;
      } else {
        const u = (t - 0.6) / 0.4;
        crx = -1.2 * (1 - u);
        cry = 0.7 * (1 - u);
        cx += -0.27 * (1 - u);
        cy += -0.02 * (1 - u);
      }
      this.crowbar.position.set(cx, cy, cz);
      this.crowbar.rotation.set(crx, cry, crz);
    }
  }

  /* ================================================================ */
  /* HUD & radar                                                        */
  /* ================================================================ */

  private pushHud() {
    const weapons: WeaponHud[] = WEAPONS.map((w, i) => ({ name: w.name, owned: this.owned[i], mag: this.mags[i], reserve: this.reserves[i], magSize: w.mag }));
    const def = WEAPONS[this.cur];
    const moving = this.vel.length() > 1;
    const spread = 5 + def.spread * 470 * (moving ? 1.8 : 1) + this.recoilV * 8 + (this.onGround ? 0 : 14);
    this.ev.onHud({
      hp: this.hp,
      stamina: this.stamina,
      weapons,
      cur: this.cur,
      reloading: this.reloading,
      reloadProg: this.reloading ? 1 - this.reloadT / def.reload : 0,
      flashlight: this.flashOn,
      wave: this.wave,
      kills: this.kills,
      score: this.score,
      remaining: this.aliveCount() + this.toSpawn.length,
      breakTime: this.waveState === "break" ? Math.max(0, this.breakT) : null,
      spread,
      sprinting: this.sprintB > 0.5,
    });
  }

  private drawRadar() {
    const ctx = this.radarCtx;
    const S = this.radar.width;
    const c = S / 2;
    const range = 42;
    const sc = c / range;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, S, S);
    ctx.save();
    ctx.beginPath();
    ctx.arc(c, c, c - 1, 0, Math.PI * 2);
    ctx.clip();
    ctx.fillStyle = "rgba(6,16,10,0.78)";
    ctx.fillRect(0, 0, S, S);
    const cs = Math.cos(this.yaw);
    const sn = Math.sin(this.yaw);
    ctx.setTransform(cs * sc, sn * sc, -sn * sc, cs * sc, c, c);
    // roads
    ctx.fillStyle = "rgba(60,90,70,0.28)";
    ctx.fillRect(-HALF - this.pos.x, -6 - this.pos.z, HALF * 2, 12);
    ctx.fillRect(-6 - this.pos.x, -HALF - this.pos.z, 12, HALF * 2);
    ctx.fillStyle = "rgba(90,150,110,0.55)";
    for (const col of this.world.colliders) {
      if (!col.building) continue;
      ctx.fillRect(col.minX - this.pos.x, col.minZ - this.pos.z, col.maxX - col.minX, col.maxZ - col.minZ);
    }
    ctx.strokeStyle = "rgba(120,200,140,0.5)";
    ctx.lineWidth = 1 / sc;
    ctx.strokeRect(-HALF - this.pos.x, -HALF - this.pos.z, HALF * 2, HALF * 2);
    for (const p of this.pickups) {
      ctx.fillStyle = p.kind === "health" ? "#5dff7a" : p.kind === "ammo" ? "#ffd34a" : "#5ac8ff";
      ctx.fillRect(p.x - this.pos.x - 1, p.z - this.pos.z - 1, 2, 2);
    }
    for (const z of this.zombies) {
      if (z.state === "dying") continue;
      ctx.fillStyle = z.type === "brute" ? "#ff9020" : "#ff3030";
      const r = z.type === "brute" ? 1.6 : 1.0;
      ctx.beginPath();
      ctx.arc(z.x - this.pos.x, z.z - this.pos.z, r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    // player cone
    ctx.fillStyle = "rgba(255,255,255,0.18)";
    ctx.beginPath();
    ctx.moveTo(c, c);
    ctx.arc(c, c, c - 2, -Math.PI / 2 - 0.65, -Math.PI / 2 + 0.65);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.moveTo(c, c - 6);
    ctx.lineTo(c + 4, c + 4);
    ctx.lineTo(c - 4, c + 4);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "rgba(120,220,150,0.7)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(c, c, c - 1, 0, Math.PI * 2);
    ctx.stroke();
  }
}
