import { useCallback, useEffect, useRef, useState } from "react";
import { Game } from "./game/Game";
import type { GameStats, HudState } from "./game/Game";

type Phase = "loading" | "menu" | "playing" | "paused" | "dead";

interface Msg {
  id: number;
  text: string;
  kind: "info" | "good" | "bad";
}

const HS_KEY = "dead-horizon-highscore";

function fmtTime(s: number) {
  const m = Math.floor(s / 60);
  const ss = Math.floor(s % 60);
  return `${m}:${ss.toString().padStart(2, "0")}`;
}

function Key({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="inline-flex min-w-7 h-7 px-1.5 items-center justify-center rounded border border-white/25 bg-white/10 text-[13px] font-semibold text-white shadow-[0_2px_0_rgba(255,255,255,0.15)]">
      {children}
    </kbd>
  );
}

function Controls() {
  const rows: [React.ReactNode, string][] = [
    [
      <span className="flex gap-1" key="m">
        <Key>W</Key>
        <Key>A</Key>
        <Key>S</Key>
        <Key>D</Key>
      </span>,
      "Mover",
    ],
    [<Key key="sh">Shift</Key>, "Correr"],
    [<Key key="sp">Espaço</Key>, "Pular"],
    [<Key key="mo">Mouse</Key>, "Mirar / Atirar (clique)"],
    [<Key key="r">R</Key>, "Recarregar"],
    [
      <span className="flex gap-1" key="n">
        <Key>1</Key>
        <Key>2</Key>
        <Key>3</Key>
      </span>,
      "Trocar de arma (ou roda do mouse)",
    ],
    [<Key key="v">V</Key>, "Golpe de pé de cabra"],
    [<Key key="f">F</Key>, "Lanterna"],
    [<Key key="p">Esc / P</Key>, "Pausar"],
  ];
  return (
    <div className="grid grid-cols-1 gap-y-2 text-sm text-white/85">
      {rows.map(([k, label], i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="w-28 shrink-0 flex justify-end">{k}</div>
          <div className="text-white/70">{label}</div>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const radarRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const idRef = useRef(1);

  const [phase, setPhase] = useState<Phase>("loading");
  const [hud, setHud] = useState<HudState | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [hurt, setHurt] = useState<{ id: number; angle: number } | null>(null);
  const [hitMark, setHitMark] = useState<{ id: number; head: boolean; kill: boolean } | null>(null);
  const [popups, setPopups] = useState<{ id: number; text: string; head: boolean }[]>([]);
  const [banner, setBanner] = useState<{ id: number; title: string; sub: string } | null>(null);
  const [stats, setStats] = useState<GameStats | null>(null);
  const [high, setHigh] = useState<number>(() => Number(localStorage.getItem(HS_KEY) || 0));
  const [newHigh, setNewHigh] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [adminCode, setAdminCode] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminMsg, setAdminMsg] = useState("");
  const [godOn, setGodOn] = useState(false);
  const [infAmmo, setInfAmmo] = useState(false);
  const [infStamina, setInfStamina] = useState(false);
  const [freezeZ, setFreezeZ] = useState(false);
  const [announceText, setAnnounceText] = useState("");
  const [skinCode, setSkinCode] = useState("");
  const [skinMsg, setSkinMsg] = useState("");
  const [sens, setSens] = useState(1);
  const [vol, setVol] = useState(0.7);
  const [webglError, setWebglError] = useState(false);

  const phaseRef = useRef<Phase>("loading");
  phaseRef.current = phase;
  const highRef = useRef(high);
  highRef.current = high;

  useEffect(() => {
    let game: Game | null = null;
    const t = setTimeout(() => {
      if (!mountRef.current || !radarRef.current) return;
      try {
        game = new Game(mountRef.current, radarRef.current, {
          onHud: (h) => setHud(h),
          onMessage: (text, kind) => {
            const id = idRef.current++;
            setMsgs((m) => [...m.slice(-3), { id, text, kind }]);
            setTimeout(() => setMsgs((m) => m.filter((x) => x.id !== id)), 3200);
          },
          onHurt: (angle) => setHurt({ id: idRef.current++, angle }),
          onHit: (head, kill, points) => {
            const id = idRef.current++;
            setHitMark({ id, head, kill });
            if (kill) {
              setPopups((p) => [...p.slice(-4), { id, text: `+${points}`, head }]);
              setTimeout(() => setPopups((p) => p.filter((x) => x.id !== id)), 900);
            }
          },
          onWave: (n, title, sub) => {
            const id = idRef.current++;
            setBanner({ id, title, sub });
            void n;
            setTimeout(() => setBanner((b) => (b && b.id === id ? null : b)), 4000);
          },
          onDead: (s) => {
            setStats(s);
            const isNew = s.score > highRef.current;
            if (isNew) {
              localStorage.setItem(HS_KEY, String(s.score));
              setHigh(s.score);
            }
            setNewHigh(isNew);
            setPhase("dead");
          },
          onPause: () => setPhase("paused"),
        });
        gameRef.current = game;
        setPhase("menu");
      } catch (e) {
        console.error(e);
        setWebglError(true);
      }
    }, 80);
    return () => {
      clearTimeout(t);
      game?.dispose();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    gameRef.current?.setSensitivity(sens);
  }, [sens, phase]);
  useEffect(() => {
    gameRef.current?.setVolume(vol);
  }, [vol, phase]);

  const start = useCallback(() => {
    setMsgs([]);
    setBanner(null);
    setHurt(null);
    gameRef.current?.setSensitivity(sens);
    gameRef.current?.setVolume(vol);
    gameRef.current?.start();
    setPhase("playing");
  }, [sens, vol]);

  const resume = useCallback(() => {
    gameRef.current?.resume();
    setPhase("playing");
  }, []);

  const toMenu = useCallback(() => {
    gameRef.current?.toMenu();
    setPhase("menu");
  }, []);

  // Enter / click shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Enter") {
        if (phaseRef.current === "menu" || phaseRef.current === "dead") {
          e.preventDefault();
          start();
        } else if (phaseRef.current === "paused") {
          e.preventDefault();
          resume();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [start, resume]);

  const tryAdminLogin = () => {
    if (adminCode.trim() === "Minecraft23#") {
      setIsAdmin(true);
      setAdminMsg("Acesso concedido! Bem-vindo, Admin.");
      setAdminCode("");
    } else {
      setAdminMsg("Código incorreto.");
    }
  };

  const closeAdmin = () => {
    setAdminOpen(false);
    setAdminMsg("");
    setAdminCode("");
  };

  const toggleGod = () => {
    const next = !godOn;
    setGodOn(next);
    gameRef.current?.setGodMode(next);
  };

  const toggleInfAmmo = () => {
    const next = !infAmmo;
    setInfAmmo(next);
    gameRef.current?.setInfiniteAmmo(next);
  };

  const doSetHp = (hp: number) => gameRef.current?.adminSetHp(hp);
  const doSpawn = (type: "walker" | "runner" | "brute") => gameRef.current?.adminSpawnZombie(type);
  const doKillAll = () => gameRef.current?.adminKillAll();
  const doSetWave = (n: number) => gameRef.current?.adminSetWave(n);
  const doGiveWeapons = () => gameRef.current?.adminGiveAllWeapons();
  const toggleStamina = () => {
    const next = !infStamina;
    setInfStamina(next);
    gameRef.current?.setInfiniteStamina(next);
  };
  const toggleFreeze = () => {
    const next = !freezeZ;
    setFreezeZ(next);
    gameRef.current?.setFreezeZombies(next);
  };
  const doSetSpeed = (mul: number) => gameRef.current?.setSpeedMultiplier(mul);
  const doToggleRain = () => gameRef.current?.toggleRain();
  const doSetScore = (s: number) => gameRef.current?.adminSetScore(s);
  const doTeleport = () => gameRef.current?.adminTeleportHome();
  const doClearPickups = () => gameRef.current?.adminClearPickups();
  const sendAnnounce = () => {
    if (announceText.trim()) {
      gameRef.current?.adminAnnounce(announceText.trim());
      setAnnounceText("");
    }
  };
  const redeemSkin = () => {
    if (skinCode.trim()) {
      const ok = gameRef.current?.applySkinCode(skinCode.trim());
      setSkinMsg(ok ? "Código resgatado!" : "Código inválido");
      if (ok) setSkinCode("");
      setTimeout(() => setSkinMsg(""), 2500);
    }
  };

  const playing = phase === "playing";
  const showHud = (playing || phase === "paused" || phase === "dead") && hud;
  const w = hud ? hud.weapons[hud.cur] : null;
  const lowHp = hud ? hud.hp < 35 : false;

  return (
    <div className="fixed inset-0 overflow-hidden bg-black text-white select-none font-hud">
      <div ref={mountRef} className="absolute inset-0" />

      {/* Radar canvas is always mounted */}
      <div className={`absolute left-5 bottom-5 z-10 transition-opacity ${showHud && phase !== "dead" ? "opacity-100" : "opacity-0"}`}>
        <canvas ref={radarRef} width={176} height={176} className="w-[176px] h-[176px] rounded-full shadow-[0_0_24px_rgba(0,0,0,0.8)]" />
      </div>

      {/* ---------------- HUD ---------------- */}
      {showHud && hud && w && phase !== "dead" && (
        <div className="pointer-events-none absolute inset-0 z-10">
          {/* hurt vignette */}
          {hurt && <div key={hurt.id} className="absolute inset-0 animate-hurt" style={{ background: "radial-gradient(ellipse at center, rgba(120,0,0,0) 35%, rgba(150,0,0,0.75) 100%)" }} />}
          {lowHp && <div className="absolute inset-0 animate-lowhp" style={{ background: "radial-gradient(ellipse at center, rgba(0,0,0,0) 40%, rgba(110,0,0,0.65) 100%)" }} />}
          {hurt && (
            <div key={`d${hurt.id}`} className="absolute left-1/2 top-1/2 w-0 h-0 animate-hurt" style={{ transform: `rotate(${hurt.angle}rad)` }}>
              <div className="absolute -left-24 -top-[190px] w-48 h-12 rounded-[100%] border-t-[10px] border-red-600/90 blur-[1.5px]" />
            </div>
          )}

          {/* crosshair */}
          <div className="absolute left-1/2 top-1/2">
            {[0, 90, 180, 270].map((deg) => (
              <div key={deg} className="absolute" style={{ transform: `rotate(${deg}deg) translateY(-${hud.spread}px)` }}>
                <div className="absolute -left-px -top-2.5 w-0.5 h-2.5 bg-white/90 shadow-[0_0_3px_#000]" />
              </div>
            ))}
            <div className="absolute -left-px -top-px w-0.5 h-0.5 bg-white/80" />
            {hitMark && (
              <div key={hitMark.id} className="absolute animate-hitmark" style={{ left: -14, top: -14, width: 28, height: 28 }}>
                {[45, 135, 225, 315].map((d) => (
                  <div
                    key={d}
                    className="absolute left-1/2 top-1/2"
                    style={{ transform: `rotate(${d}deg) translateY(-9px)` }}
                  >
                    <div className={`w-0.5 h-2.5 -ml-px ${hitMark.kill ? "bg-red-500" : hitMark.head ? "bg-yellow-300" : "bg-white"}`} />
                  </div>
                ))}
              </div>
            )}
            {popups.map((p) => (
              <div key={p.id} className={`absolute animate-popup font-title text-xl whitespace-nowrap ${p.head ? "text-yellow-300" : "text-red-400"}`} style={{ left: 26, top: -26 }}>
                {p.text}
                {p.head && <span className="ml-1 text-xs align-middle">HEADSHOT</span>}
              </div>
            ))}
            {hud.reloading && (
              <div className="absolute -left-14 top-9 w-28">
                <div className="text-center text-[11px] tracking-[0.25em] text-white/80 mb-1">RECARREGANDO</div>
                <div className="h-1 bg-white/20 rounded">
                  <div className="h-full bg-white/90 rounded" style={{ width: `${hud.reloadProg * 100}%` }} />
                </div>
              </div>
            )}
          </div>

          {/* top-left: wave */}
          <div className="absolute left-6 top-5">
            <div className="font-title text-4xl tracking-wider text-red-500 drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">ONDA {Math.max(1, hud.wave)}</div>
            <div className="text-sm tracking-[0.2em] text-white/80 drop-shadow">
              {hud.breakTime !== null ? (
                <span className="text-emerald-300">{hud.wave === 0 ? "PRIMEIRA ONDA EM" : "PRÓXIMA ONDA EM"} {Math.ceil(hud.breakTime)}s</span>
              ) : (
                <span>ZUMBIS RESTANTES: <b className="text-white">{hud.remaining}</b></span>
              )}
            </div>
          </div>

          {/* top-right: score */}
          <div className="absolute right-6 top-5 text-right drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
            <div className="text-xs tracking-[0.3em] text-white/60">PONTOS</div>
            <div className="font-title text-4xl text-amber-300 tabular-nums">{hud.score.toLocaleString("pt-BR")}</div>
            <div className="text-sm tracking-widest text-white/70">ABATES <b className="text-white">{hud.kills}</b></div>
          </div>

          {/* wave banner */}
          {banner && (
            <div key={banner.id} className="absolute left-0 right-0 top-[22%] text-center animate-banner">
              <div className="font-title text-6xl md:text-7xl tracking-[0.15em] text-red-600 drop-shadow-[0_0_24px_rgba(220,0,0,0.7)]">{banner.title}</div>
              <div className="mt-2 text-lg tracking-[0.35em] text-white/85 uppercase">{banner.sub}</div>
            </div>
          )}

          {/* messages */}
          <div className="absolute left-1/2 -translate-x-1/2 bottom-24 flex flex-col items-center gap-1">
            {msgs.map((m) => (
              <div
                key={m.id}
                className={`animate-msg px-4 py-1 rounded bg-black/55 text-sm tracking-widest ${m.kind === "good" ? "text-emerald-300" : m.kind === "bad" ? "text-red-400" : "text-white/90"}`}
              >
                {m.text}
              </div>
            ))}
          </div>

          {/* bars */}
          <div className="absolute left-[212px] bottom-6 w-60 space-y-2">
            <div>
              <div className="flex justify-between text-[11px] tracking-[0.25em] text-white/70 mb-0.5">
                <span>VIDA</span>
                <span className="tabular-nums">{Math.ceil(hud.hp)}</span>
              </div>
              <div className="h-3 bg-black/60 border border-white/20 rounded-sm overflow-hidden">
                <div
                  className={`h-full transition-[width] duration-150 ${lowHp ? "bg-red-600" : "bg-gradient-to-r from-red-700 to-red-500"}`}
                  style={{ width: `${hud.hp}%` }}
                />
              </div>
            </div>
            <div>
              <div className="text-[11px] tracking-[0.25em] text-white/70 mb-0.5">ESTAMINA</div>
              <div className="h-1.5 bg-black/60 border border-white/20 rounded-sm overflow-hidden">
                <div className="h-full bg-gradient-to-r from-amber-600 to-yellow-300" style={{ width: `${hud.stamina}%` }} />
              </div>
            </div>
            <div className="text-[11px] tracking-[0.2em] text-white/60">
              LANTERNA [F]: <span className={hud.flashlight ? "text-yellow-200" : "text-white/40"}>{hud.flashlight ? "LIGADA" : "DESLIGADA"}</span>
            </div>
          </div>

          {/* weapon */}
          <div className="absolute right-6 bottom-5 text-right">
            <div className="text-xs tracking-[0.3em] text-white/70 drop-shadow">{w.name}</div>
            <div className="flex items-baseline justify-end gap-2 drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
              <span className={`font-title text-6xl tabular-nums ${w.mag === 0 ? "text-red-500" : w.mag <= w.magSize * 0.25 ? "text-amber-300" : "text-white"}`}>{w.mag}</span>
              <span className="font-title text-2xl text-white/60 tabular-nums">/ {w.reserve}</span>
            </div>
            <div className="mt-2 flex gap-2 justify-end">
              {hud.weapons.map((wp, i) => (
                <div
                  key={i}
                  className={`w-28 px-2 py-1 border rounded-sm text-left text-[10px] tracking-wider ${
                    i === hud.cur ? "border-amber-300 bg-amber-300/15 text-amber-100" : wp.owned ? "border-white/30 bg-black/50 text-white/80" : "border-white/10 bg-black/30 text-white/25"
                  }`}
                >
                  <div className="flex justify-between">
                    <b>{i + 1}</b>
                    <span>{wp.owned ? `${wp.mag}/${wp.reserve}` : "🔒"}</span>
                  </div>
                  <div className="truncate">{wp.name}</div>
                </div>
              ))}
            </div>
            <div className="mt-1 text-[10px] tracking-[0.25em] text-white/45">[R] RECARREGAR &nbsp; [V] CORPO A CORPO</div>
          </div>
        </div>
      )}

      {/* ---------------- Screens ---------------- */}
      {(phase === "loading" || webglError) && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black">
          {webglError ? (
            <>
              <div className="font-title text-4xl text-red-500">WebGL indisponível</div>
              <p className="mt-3 text-white/70">Seu navegador não conseguiu iniciar o 3D. Ative a aceleração de hardware e recarregue.</p>
            </>
          ) : (
            <>
              <div className="font-title text-5xl tracking-widest text-red-600 animate-pulse">DEAD HORIZON</div>
              <div className="mt-4 text-sm tracking-[0.4em] text-white/60">GERANDO TEXTURAS E MUNDO...</div>
              <div className="mt-5 w-64 h-1 bg-white/10 overflow-hidden rounded">
                <div className="h-full w-1/3 bg-red-600 animate-loadbar" />
              </div>
            </>
          )}
        </div>
      )}

      {phase === "menu" && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-gradient-to-b from-black/70 via-black/40 to-black/80 overflow-y-auto">
          <div className="w-full max-w-5xl px-6 py-8 grid md:grid-cols-[1.2fr_1fr] gap-10 items-center">
            <div>
              <div className="text-sm tracking-[0.6em] text-red-400/90 mb-2">APOCALIPSE ZUMBI</div>
              <h1 className="font-title text-6xl md:text-8xl leading-none tracking-wider text-red-600 animate-flicker drop-shadow-[0_0_30px_rgba(200,0,0,0.55)]">
                DEAD
                <br />
                HORIZON
              </h1>
              <p className="mt-5 max-w-md text-white/75 leading-relaxed">
                A cidade caiu. Está escuro, chovendo e eles estão em toda parte. Encontre armas, explore as ruas, explode barris e sobreviva ao maior número possível de ondas.
              </p>
              <button
                onClick={start}
                className="mt-8 group relative px-10 py-4 font-title text-2xl tracking-[0.2em] bg-red-700 hover:bg-red-600 active:scale-[0.98] transition border border-red-400/60 shadow-[0_0_30px_rgba(220,30,30,0.45)]"
              >
                INICIAR SOBREVIVÊNCIA
              </button>
              <div className="mt-3 text-xs tracking-[0.3em] text-white/45">OU PRESSIONE ENTER</div>
              <button
                onClick={() => setAdminOpen(true)}
                className="mt-4 px-6 py-2 text-sm tracking-[0.2em] bg-white/10 hover:bg-white/20 border border-white/30 transition"
              >
                PAINEL ADMIN
              </button>
              {high > 0 && (
                <div className="mt-6 text-sm tracking-[0.25em] text-amber-300/90">
                  RECORDE: <b className="font-title text-xl tabular-nums">{high.toLocaleString("pt-BR")}</b>
                </div>
              )}
              <div className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 max-w-md text-sm">
                <label className="flex flex-col gap-1 text-white/70 tracking-widest text-xs">
                  SENSIBILIDADE
                  <input type="range" min={0.3} max={2.5} step={0.05} value={sens} onChange={(e) => setSens(Number(e.target.value))} className="accent-red-600" />
                </label>
                <label className="flex flex-col gap-1 text-white/70 tracking-widest text-xs">
                  VOLUME
                  <input type="range" min={0} max={1} step={0.05} value={vol} onChange={(e) => setVol(Number(e.target.value))} className="accent-red-600" />
                </label>
              </div>
            </div>
            <div className="rounded-lg border border-white/10 bg-black/55 backdrop-blur-sm p-6">
              <div className="text-xs tracking-[0.4em] text-white/50 mb-4">CONTROLES</div>
              <Controls />
              <div className="mt-5 pt-4 border-t border-white/10 text-xs text-white/55 leading-relaxed">
                <b className="text-sky-300">Dicas:</b> acerte a cabeça para dano ×2,5. Barris vermelhos explodem. Pegue a espingarda e o rifle (feixes de luz azuis) no mapa. Corredores são rápidos, brutamontes aguentam muito dano.
              </div>
            </div>
          </div>
        </div>
      )}

      {phase === "paused" && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/70 backdrop-blur-[2px]">
          <div className="text-center">
            <div className="font-title text-6xl tracking-[0.2em] text-white">PAUSADO</div>
            <div className="mt-8 flex flex-col gap-3 items-center">
              <button onClick={resume} className="w-72 py-3 font-title text-xl tracking-[0.2em] bg-red-700 hover:bg-red-600 border border-red-400/60 transition">
                CONTINUAR
              </button>
              <button onClick={toMenu} className="w-72 py-3 font-title text-xl tracking-[0.2em] bg-white/10 hover:bg-white/20 border border-white/25 transition">
                MENU PRINCIPAL
              </button>
            </div>
            <div className="mt-8 mx-auto w-fit rounded-lg border border-white/10 bg-black/50 p-5">
              <Controls />
            </div>
          </div>
        </div>
      )}

      {phase === "dead" && stats && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-gradient-to-b from-red-950/70 to-black/90 animate-fadein">
          <div className="text-center px-4">
            <div className="font-title text-7xl md:text-8xl tracking-[0.12em] text-red-600 drop-shadow-[0_0_30px_rgba(220,0,0,0.6)]">VOCÊ MORREU</div>
            <div className="mt-2 text-white/70 tracking-[0.3em] text-sm">SOBREVIVEU ATÉ A ONDA {Math.max(1, stats.wave)}</div>
            {newHigh && <div className="mt-3 font-title text-2xl text-amber-300 animate-pulse tracking-widest">NOVO RECORDE!</div>}
            <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
              {[
                ["PONTOS", stats.score.toLocaleString("pt-BR")],
                ["ABATES", String(stats.kills)],
                ["HEADSHOTS", String(stats.headshots)],
                ["PRECISÃO", stats.shots ? `${Math.min(100, Math.round((stats.hits / stats.shots) * 100))}%` : "—"],
              ].map(([k, v]) => (
                <div key={k} className="border border-white/15 bg-black/50 rounded px-4 py-3">
                  <div className="text-[11px] tracking-[0.3em] text-white/55">{k}</div>
                  <div className="font-title text-3xl text-white tabular-nums">{v}</div>
                </div>
              ))}
            </div>
            <div className="mt-4 text-white/55 text-sm tracking-widest">TEMPO DE SOBREVIVÊNCIA {fmtTime(stats.time)} &nbsp;•&nbsp; RECORDE {high.toLocaleString("pt-BR")}</div>
            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
              <button onClick={start} className="px-10 py-3 font-title text-xl tracking-[0.2em] bg-red-700 hover:bg-red-600 border border-red-400/60 transition">
                TENTAR NOVAMENTE
              </button>
              <button onClick={toMenu} className="px-10 py-3 font-title text-xl tracking-[0.2em] bg-white/10 hover:bg-white/20 border border-white/25 transition">
                MENU
              </button>
            </div>
          </div>
        </div>
      )}

      {adminOpen && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/80 p-4">
          <div className="w-full max-w-2xl bg-zinc-900 border border-red-600/50 rounded-lg p-6 shadow-2xl">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-title text-3xl text-red-500 tracking-wider">PAINEL ADMIN</h2>
              <button onClick={closeAdmin} className="text-white/60 hover:text-white text-2xl leading-none">&times;</button>
            </div>
            {!isAdmin ? (
              <div className="space-y-4">
                <p className="text-white/70">Digite o código de acesso:</p>
                <input
                  type="password"
                  value={adminCode}
                  onChange={(e) => setAdminCode(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && tryAdminLogin()}
                  placeholder="Código secreto"
                  className="w-full px-4 py-3 bg-black/50 border border-white/20 rounded text-white focus:border-red-500 outline-none"
                  autoFocus
                />
                <button onClick={tryAdminLogin} className="w-full py-3 bg-red-700 hover:bg-red-600 font-title tracking-widest">
                  ENTRAR
                </button>
                {adminMsg && <p className="text-center text-red-400">{adminMsg}</p>}
              </div>
            ) : (
              <div className="space-y-5 max-h-[70vh] overflow-y-auto pr-2">
                <p className="text-emerald-400 text-center">{adminMsg}</p>
                
                <div className="grid grid-cols-2 gap-3">
                  <button onClick={toggleGod} className={`py-2 border ${godOn ? "bg-emerald-700 border-emerald-400" : "bg-white/10 border-white/20"}`}>
                    {godOn ? "DEUS: ON" : "DEUS: OFF"}
                  </button>
                  <button onClick={toggleInfAmmo} className={`py-2 border ${infAmmo ? "bg-emerald-700 border-emerald-400" : "bg-white/10 border-white/20"}`}>
                    {infAmmo ? "MUNIÇÃO ∞: ON" : "MUNIÇÃO ∞: OFF"}
                  </button>
                  <button onClick={doGiveWeapons} className="py-2 bg-amber-700/80 hover:bg-amber-600 border border-amber-400">
                    DAR TODAS ARMAS
                  </button>
                  <button onClick={doKillAll} className="py-2 bg-red-800 hover:bg-red-700 border border-red-400">
                    MATAR TODOS ZUMBIS
                  </button>
                </div>

                <div>
                  <p className="text-xs tracking-widest text-white/50 mb-2">VIDA</p>
                  <div className="flex gap-2">
                    {[50, 100, 200, 500].map(h => (
                      <button key={h} onClick={() => doSetHp(h)} className="flex-1 py-1 bg-white/10 hover:bg-white/20 text-sm">{h}</button>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-xs tracking-widest text-white/50 mb-2">SPAWNAR ZUMBI</p>
                  <div className="flex gap-2">
                    <button onClick={() => doSpawn("walker")} className="flex-1 py-2 bg-white/10 hover:bg-white/20">WALKER</button>
                    <button onClick={() => doSpawn("runner")} className="flex-1 py-2 bg-white/10 hover:bg-white/20">RUNNER</button>
                    <button onClick={() => doSpawn("brute")} className="flex-1 py-2 bg-white/10 hover:bg-white/20">BRUTE</button>
                  </div>
                </div>

                <div>
                  <p className="text-xs tracking-widest text-white/50 mb-2">DEFINIR ONDA</p>
                  <div className="flex gap-2 flex-wrap">
                    {[1, 5, 10, 20, 50].map(w => (
                      <button key={w} onClick={() => doSetWave(w)} className="px-4 py-1 bg-white/10 hover:bg-white/20 text-sm">ONDA {w}</button>
                    ))}
                  </div>
                </div>

                {/* Anúncios */}
                <div className="border-t border-white/10 pt-4">
                  <h3 className="font-title text-xl text-red-400 mb-2 tracking-wider">ANÚNCIOS</h3>
                  <div className="flex gap-2">
                    <input
                      value={announceText}
                      onChange={(e) => setAnnounceText(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && sendAnnounce()}
                      placeholder="Mensagem para todos os jogadores..."
                      className="flex-1 px-3 py-2 bg-black/50 border border-white/20 rounded text-white text-sm outline-none focus:border-red-500"
                    />
                    <button onClick={sendAnnounce} className="px-4 py-2 bg-red-700 hover:bg-red-600 text-sm font-semibold">
                      ENVIAR
                    </button>
                  </div>
                  <p className="text-xs text-white/40 mt-1">Aparece em tela cheia como banner.</p>
                </div>

                {/* Códigos de Skins */}
                <div className="border-t border-white/10 pt-4">
                  <h3 className="font-title text-xl text-amber-300 mb-2 tracking-wider">CÓDIGOS DE SKINS</h3>
                  <div className="flex gap-2">
                    <input
                      value={skinCode}
                      onChange={(e) => setSkinCode(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && redeemSkin()}
                      placeholder="Ex: NEON, GOLD, BLOOD, ICE, SHADOW, MINECRAFT23"
                      className="flex-1 px-3 py-2 bg-black/50 border border-white/20 rounded text-white text-sm outline-none focus:border-amber-500"
                    />
                    <button onClick={redeemSkin} className="px-4 py-2 bg-amber-700 hover:bg-amber-600 text-sm font-semibold">
                      RESGATAR
                    </button>
                  </div>
                  {skinMsg && <p className="text-xs text-center mt-1 text-amber-300">{skinMsg}</p>}
                  <div className="mt-2 flex flex-wrap gap-1">
                    {["NEON", "GOLD", "BLOOD", "ICE", "SHADOW", "MINECRAFT23"].map(c => (
                      <button key={c} onClick={() => { setSkinCode(c); }} className="px-2 py-0.5 text-[10px] bg-white/10 hover:bg-white/20 rounded">
                        {c}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Controles Extras */}
                <div className="border-t border-white/10 pt-4">
                  <h3 className="font-title text-xl text-cyan-300 mb-2 tracking-wider">CONTROLES EXTRAS</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={toggleStamina} className={`py-2 text-sm border ${infStamina ? "bg-emerald-700 border-emerald-400" : "bg-white/10 border-white/20"}`}>
                      {infStamina ? "STAMINA ∞: ON" : "STAMINA ∞: OFF"}
                    </button>
                    <button onClick={toggleFreeze} className={`py-2 text-sm border ${freezeZ ? "bg-cyan-700 border-cyan-400" : "bg-white/10 border-white/20"}`}>
                      {freezeZ ? "CONGELAR: ON" : "CONGELAR: OFF"}
                    </button>
                    <button onClick={doToggleRain} className="py-2 text-sm bg-white/10 hover:bg-white/20 border border-white/20">
                      TOGGLE CHUVA
                    </button>
                    <button onClick={doTeleport} className="py-2 text-sm bg-white/10 hover:bg-white/20 border border-white/20">
                      TELEPORT CENTRO
                    </button>
                    <button onClick={doClearPickups} className="py-2 text-sm bg-white/10 hover:bg-white/20 border border-white/20">
                      LIMPAR ITENS
                    </button>
                    <button onClick={() => doSetScore(99999)} className="py-2 text-sm bg-amber-700/70 hover:bg-amber-600 border border-amber-400">
                      SCORE 99999
                    </button>
                  </div>
                  <div className="mt-2">
                    <p className="text-xs tracking-widest text-white/50 mb-1">VELOCIDADE</p>
                    <div className="flex gap-1">
                      {[1, 1.5, 2, 3, 5].map(s => (
                        <button key={s} onClick={() => doSetSpeed(s)} className="flex-1 py-1 text-xs bg-white/10 hover:bg-white/20">
                          {s}x
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="border-t border-white/10 pt-4">
                  <h3 className="font-title text-xl text-amber-300 mb-3 tracking-wider">GESTÃO DE 3 JOGADORES</h3>
                  <div className="space-y-3">
                    {["Jogador 1 (Você)", "Jogador 2 (Bot)", "Jogador 3 (Bot)"].map((name, i) => (
                      <div key={i} className="flex items-center justify-between bg-black/40 p-3 rounded border border-white/10">
                        <div>
                          <div className="font-semibold">{name}</div>
                          <div className="text-xs text-white/50">Status: {i === 0 ? "Online" : "Offline"} • HP: {i === 0 ? "100" : "—"}</div>
                        </div>
                        <div className="flex gap-1">
                          <button className="px-2 py-1 text-xs bg-blue-700/60 hover:bg-blue-600 rounded">Kick</button>
                          <button className="px-2 py-1 text-xs bg-red-700/60 hover:bg-red-600 rounded">Ban</button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <p className="mt-2 text-xs text-white/40">Painel preparado para até 3 jogadores (modo cooperativo futuro).</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* film grain / vignette overlay */}
      <div className="pointer-events-none absolute inset-0 z-[5]" style={{ background: "radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 100%)" }} />
    </div>
  );
}
